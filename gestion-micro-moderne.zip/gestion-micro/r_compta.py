# -*- coding: utf-8 -*-
"""Routes : livre des recettes, dépenses, déclarations URSSAF, rapports, simulateurs, exports."""
import csv
import io
import os
import time
import zipfile
from datetime import date

from flask import (Response, abort, flash, redirect, render_template, request, send_file,
                   send_from_directory, url_for)
from werkzeug.utils import secure_filename

import outils
import pdf
import r_documents
from outils import CATEGORIES_DEPENSES, MODES_PAIEMENT, get_db, get_params, lire_nombre, num

EXTENSIONS_JUSTIFICATIFS = ("pdf", "png", "jpg", "jpeg", "webp")


def recettes_de_l_annee(db, annee):
    return db.execute("SELECT * FROM recettes WHERE substr(date_encaissement, 1, 4) = ? "
                      "ORDER BY date_encaissement, id", (str(annee),)).fetchall()


def depenses_de_l_annee(db, annee, categorie=""):
    if categorie:
        return db.execute("SELECT * FROM depenses WHERE substr(date, 1, 4) = ? AND categorie = ? "
                          "ORDER BY date, id", (str(annee), categorie)).fetchall()
    return db.execute("SELECT * FROM depenses WHERE substr(date, 1, 4) = ? ORDER BY date, id",
                      (str(annee),)).fetchall()


def csv_recettes(db, annee):
    tampon = io.StringIO()
    ecrivain = csv.writer(tampon, delimiter=";")
    ecrivain.writerow(["Date", "Référence", "Client", "Nature", "Mode de règlement", "Montant"])
    for r in recettes_de_l_annee(db, annee):
        ecrivain.writerow([r["date_encaissement"], r["reference"], r["client"], r["nature"],
                           r["mode_paiement"], "{:.2f}".format(r["montant"]).replace(".", ",")])
    return "\ufeff" + tampon.getvalue()


def csv_depenses(db, annee):
    tampon = io.StringIO()
    ecrivain = csv.writer(tampon, delimiter=";")
    ecrivain.writerow(["Date", "Fournisseur", "Description", "Catégorie", "Mode de règlement", "Montant", "Justificatif"])
    for d in depenses_de_l_annee(db, annee):
        ecrivain.writerow([d["date"], d["fournisseur"], d["description"], d["categorie"], d["mode_paiement"],
                           "{:.2f}".format(d["montant"]).replace(".", ","), d["justificatif"]])
    return "\ufeff" + tampon.getvalue()


def csv_documents(db, params, annee):
    tampon = io.StringIO()
    ecrivain = csv.writer(tampon, delimiter=";")
    ecrivain.writerow(["Numéro", "Type", "Client", "Date d'émission", "Échéance", "Total HT", "TVA", "Total TTC",
                       "Payé", "Statut", "Date de dernier paiement"])
    for d in db.execute("SELECT d.*, c.nom AS client_nom FROM documents d JOIN clients c ON c.id = d.client_id "
                        "WHERE substr(d.date_emission, 1, 4) = ? ORDER BY d.numero", (str(annee),)):
        t = outils.totaux_document(db, d["id"], params)
        ecrivain.writerow([d["numero"], outils.TYPES_DOC[d["type"]], d["client_nom"], d["date_emission"],
                           d["date_limite"], "{:.2f}".format(t["ht"]).replace(".", ","),
                           "{:.2f}".format(t["tva"]).replace(".", ","), "{:.2f}".format(t["ttc"]).replace(".", ","),
                           "{:.2f}".format(t["paye"]).replace(".", ","), outils.STATUTS.get(d["statut"], d["statut"]),
                           d["date_paiement"]])
    return "\ufeff" + tampon.getvalue()


def reponse_csv(contenu, nom):
    return Response(contenu, mimetype="text/csv; charset=utf-8",
                    headers={"Content-Disposition": "attachment; filename=" + nom})


def reponse_pdf(contenu, nom):
    return send_file(io.BytesIO(contenu), mimetype="application/pdf", download_name=nom)


def enregistrer(app):
    # ------------------------------------------------------------ livre des recettes
    @app.route("/recettes")
    def recettes():
        db = get_db()
        annee = request.args.get("annee", type=int) or date.today().year
        liste = recettes_de_l_annee(db, annee)
        total = round(sum([r["montant"] for r in liste]), 2)
        mois = [0.0] * 12
        for r in liste:
            mois[int(r["date_encaissement"][5:7]) - 1] += r["montant"]
        return render_template("recettes.html", recettes=liste, total=total, annee=annee,
                               annees=outils.annees_disponibles(db), mois=mois, mois_noms=outils.MOIS)

    @app.route("/recettes/nouvelle", methods=["POST"])
    def recette_nouvelle():
        db = get_db()
        montant = lire_nombre(request.form.get("montant", ""), 0.0)
        date_enc = request.form.get("date_encaissement") or date.today().isoformat()
        if montant == 0:
            flash("Le montant doit être différent de 0.", "danger")
            return redirect(url_for("recettes"))
        db.execute("INSERT INTO recettes (date_encaissement, reference, client, nature, montant, mode_paiement) "
                   "VALUES (?, ?, ?, ?, ?, ?)",
                   (date_enc, request.form.get("reference", "").strip(), request.form.get("client", "").strip(),
                    request.form.get("nature", "").strip(), montant, request.form.get("mode_paiement", "")))
        db.commit()
        flash("Recette ajoutée.", "ok")
        return redirect(url_for("recettes", annee=date_enc[:4]))

    @app.route("/recettes/<int:recette_id>/supprimer", methods=["POST"])
    def recette_supprimer(recette_id):
        db = get_db()
        ligne = db.execute("SELECT * FROM recettes WHERE id = ?", (recette_id,)).fetchone()
        if ligne is None:
            abort(404)
        if ligne["document_id"]:
            flash("Recette liée à une facture : supprimer le paiement depuis la facture.", "danger")
        else:
            db.execute("DELETE FROM recettes WHERE id = ?", (recette_id,))
            db.commit()
            flash("Recette supprimée.", "ok")
        return redirect(url_for("recettes", annee=ligne["date_encaissement"][:4]))

    @app.route("/recettes/export.csv")
    def recettes_csv():
        annee = request.args.get("annee", type=int) or date.today().year
        return reponse_csv(csv_recettes(get_db(), annee), "livre-des-recettes-{}.csv".format(annee))

    @app.route("/recettes/export.pdf")
    def recettes_pdf():
        db = get_db()
        annee = request.args.get("annee", type=int) or date.today().year
        contenu = pdf.pdf_recettes([dict(r) for r in recettes_de_l_annee(db, annee)], annee, get_params(db))
        return reponse_pdf(contenu, "livre-des-recettes-{}.pdf".format(annee))

    # ------------------------------------------------------------ dépenses
    @app.route("/depenses", methods=["GET", "POST"])
    def depenses():
        db = get_db()
        if request.method == "POST":
            montant = lire_nombre(request.form.get("montant", ""), 0.0)
            if montant <= 0:
                flash("Le montant doit être supérieur à 0.", "danger")
                return redirect(url_for("depenses"))
            ident = request.form.get("id", type=int)
            fichier = request.files.get("justificatif")
            nom_fichier = ""
            if fichier is not None and fichier.filename:
                extension = fichier.filename.rsplit(".", 1)[-1].lower() if "." in fichier.filename else ""
                if extension not in EXTENSIONS_JUSTIFICATIFS:
                    flash("Justificatif refusé : formats acceptés PDF, PNG, JPG, WEBP.", "danger")
                    return redirect(url_for("depenses"))
                nom_fichier = "{}-{}".format(int(time.time()), secure_filename(fichier.filename))
                fichier.save(os.path.join(outils.DOSSIER_JUSTIFICATIFS, nom_fichier))
            valeurs = (request.form.get("date") or date.today().isoformat(), request.form.get("fournisseur", "").strip(),
                       request.form.get("description", "").strip(), request.form.get("categorie", ""), montant,
                       request.form.get("mode_paiement", ""))
            if ident:
                db.execute("UPDATE depenses SET date=?, fournisseur=?, description=?, categorie=?, montant=?, "
                           "mode_paiement=? WHERE id=?", valeurs + (ident,))
                if nom_fichier:
                    db.execute("UPDATE depenses SET justificatif = ? WHERE id = ?", (nom_fichier, ident))
                flash("Dépense modifiée.", "ok")
            else:
                db.execute("INSERT INTO depenses (date, fournisseur, description, categorie, montant, mode_paiement, "
                           "justificatif) VALUES (?, ?, ?, ?, ?, ?, ?)", valeurs + (nom_fichier,))
                flash("Dépense ajoutée.", "ok")
            db.commit()
            return redirect(url_for("depenses", annee=valeurs[0][:4]))
        annee = request.args.get("annee", type=int) or date.today().year
        categorie = request.args.get("categorie", "")
        liste = depenses_de_l_annee(db, annee, categorie)
        total = round(sum([d["montant"] for d in liste]), 2)
        par_categorie = db.execute("SELECT categorie, SUM(montant) AS total FROM depenses WHERE "
                                   "substr(date, 1, 4) = ? GROUP BY categorie ORDER BY total DESC",
                                   (str(annee),)).fetchall()
        modifier = request.args.get("modifier", type=int)
        edition = None
        if modifier:
            edition = db.execute("SELECT * FROM depenses WHERE id = ?", (modifier,)).fetchone()
        return render_template("depenses.html", liste=liste, total=total, annee=annee, categorie=categorie,
                               par_categorie=par_categorie, edition=edition, categories=CATEGORIES_DEPENSES,
                               annees=outils.annees_disponibles(db), aujourdhui=date.today().isoformat())

    @app.route("/depenses/<int:ident>/supprimer", methods=["POST"])
    def depense_supprimer(ident):
        db = get_db()
        d = db.execute("SELECT * FROM depenses WHERE id = ?", (ident,)).fetchone()
        if d is None:
            abort(404)
        db.execute("DELETE FROM depenses WHERE id = ?", (ident,))
        db.commit()
        flash("Dépense supprimée (le justificatif reste dans le dossier data/justificatifs).", "ok")
        return redirect(url_for("depenses", annee=d["date"][:4]))

    @app.route("/justificatifs/<nom>")
    def justificatif(nom):
        return send_from_directory(outils.DOSSIER_JUSTIFICATIFS, nom)

    @app.route("/depenses/export.csv")
    def depenses_csv():
        annee = request.args.get("annee", type=int) or date.today().year
        return reponse_csv(csv_depenses(get_db(), annee), "depenses-{}.csv".format(annee))

    @app.route("/depenses/export.pdf")
    def depenses_pdf():
        db = get_db()
        annee = request.args.get("annee", type=int) or date.today().year
        contenu = pdf.pdf_depenses([dict(d) for d in depenses_de_l_annee(db, annee)], annee, get_params(db))
        return reponse_pdf(contenu, "depenses-{}.pdf".format(annee))

    # ------------------------------------------------------------ déclarations URSSAF
    @app.route("/declarations")
    def declarations():
        db = get_db()
        params = get_params(db)
        annee = request.args.get("annee", type=int) or date.today().year
        etat = outils.etat_declarations(db, params, annee)
        total_ca = round(sum([p["ca"] for p in etat]), 2)
        total_cotis = round(sum([p["cotisations"] for p in etat]), 2)
        total_vl = round(sum([p["vl"] for p in etat]), 2)
        return render_template("declarations.html", etat=etat, annee=annee, params=params,
                               total_ca=total_ca, total_cotis=total_cotis, total_vl=total_vl,
                               statuts=outils.STATUTS_DECLARATION, annees=outils.annees_disponibles(db),
                               aujourdhui=date.today().isoformat())

    @app.route("/declarations/<cle>/marquer", methods=["POST"])
    def declaration_marquer(cle):
        db = get_db()
        declare = request.form.get("declare_le", "")
        paye = request.form.get("paye_le", "")
        db.execute("INSERT OR REPLACE INTO declarations (periode, ca_declare, declare_le, paye_le, montant_paye) "
                   "VALUES (?, ?, ?, ?, ?)",
                   (cle, lire_nombre(request.form.get("ca_declare", ""), 0.0), declare, paye,
                    lire_nombre(request.form.get("montant_paye", ""), 0.0)))
        db.commit()
        flash("Déclaration enregistrée.", "ok")
        return redirect(url_for("declarations", annee=cle[:4]))

    @app.route("/declarations/<cle>/effacer", methods=["POST"])
    def declaration_effacer(cle):
        db = get_db()
        db.execute("DELETE FROM declarations WHERE periode = ?", (cle,))
        db.commit()
        return redirect(url_for("declarations", annee=cle[:4]))

    # ------------------------------------------------------------ rapports
    @app.route("/rapports")
    def rapports():
        db = get_db()
        params = get_params(db)
        annee = request.args.get("annee", type=int) or date.today().year

        def ca_par_mois(a):
            mois = [0.0] * 12
            for r in db.execute("SELECT substr(date_encaissement, 6, 2) AS m, SUM(montant) AS t FROM recettes "
                                "WHERE substr(date_encaissement, 1, 4) = ? GROUP BY m", (str(a),)):
                mois[int(r["m"]) - 1] = r["t"]
            return mois

        n = ca_par_mois(annee)
        n1 = ca_par_mois(annee - 1)
        ca = round(sum(n), 2)
        clients = []
        for r in db.execute("SELECT COALESCE(c.nom, NULLIF(r.client, ''), 'Sans client') AS nom, SUM(r.montant) AS total "
                            "FROM recettes r LEFT JOIN documents d ON d.id = r.document_id "
                            "LEFT JOIN clients c ON c.id = d.client_id WHERE substr(r.date_encaissement, 1, 4) = ? "
                            "GROUP BY nom ORDER BY total DESC", (str(annee),)):
            clients.append({"nom": r["nom"], "total": round(r["total"], 2),
                            "pct": r["total"] / ca * 100 if ca > 0 else 0})
        types = db.execute("SELECT type, COUNT(*) AS nb, COALESCE(SUM(duree_minutes), 0) AS minutes FROM interventions "
                           "WHERE substr(date, 1, 4) = ? GROUP BY type ORDER BY minutes DESC", (str(annee),)).fetchall()
        minutes_facturables = db.execute("SELECT COALESCE(SUM(duree_minutes), 0) FROM interventions WHERE "
                                         "substr(date, 1, 4) = ? AND facturable = 1", (str(annee),)).fetchone()[0]
        taux_effectif = round(ca / (minutes_facturables / 60), 2) if minutes_facturables > 0 else None
        categories = db.execute("SELECT categorie, SUM(montant) AS total FROM depenses WHERE substr(date, 1, 4) = ? "
                                "GROUP BY categorie ORDER BY total DESC", (str(annee),)).fetchall()
        depenses_total = round(sum([c["total"] for c in categories]), 2)
        delais = []
        for d in db.execute("SELECT d.date_emission, MAX(p.date) AS dernier FROM documents d JOIN paiements p ON "
                            "p.document_id = d.id WHERE d.type = 'facture' AND d.statut = 'payee' AND "
                            "substr(d.date_emission, 1, 4) = ? GROUP BY d.id", (str(annee),)):
            delais.append((date.fromisoformat(d["dernier"]) - date.fromisoformat(d["date_emission"])).days)
        delai_moyen = round(sum(delais) / len(delais), 1) if delais else None
        concentration = clients[0] if clients and clients[0]["pct"] >= 50 and len(clients) > 1 else None
        return render_template("rapports.html", annee=annee, n=n, n1=n1, ca=ca, clients=clients, types=types,
                               minutes_facturables=minutes_facturables, taux_effectif=taux_effectif,
                               categories=categories, depenses_total=depenses_total, delai_moyen=delai_moyen,
                               concentration=concentration, resultat=round(ca - depenses_total, 2),
                               annees=outils.annees_disponibles(db), mois_noms=outils.MOIS)

    # ------------------------------------------------------------ simulateurs
    @app.route("/simulateurs")
    def simulateurs():
        db = get_db()
        params = get_params(db)
        cotis, vl = outils.taux_charges(params)
        part_charges = cotis + vl
        stats = outils.calcul_stats(db, params, date.today().year)
        plafond = outils.plafond_proratise(params, date.today().year)[0]
        resultats = {}
        a = request.args
        if a.get("sim") == "tarif":
            net = lire_nombre(a.get("net", ""), 0.0)
            heures = lire_nombre(a.get("heures", ""), 0.0)
            charges = lire_nombre(a.get("charges", ""), 0.0)
            if net > 0 and heures > 0 and part_charges < 1:
                ca_mensuel = (net + charges) / (1 - part_charges)
                ca_annuel = ca_mensuel * 12
                resultats["tarif"] = {"ca_mensuel": round(ca_mensuel, 2), "ca_annuel": round(ca_annuel, 2),
                                      "taux": round(ca_mensuel / heures, 2),
                                      "pct_plafond": round(ca_annuel / plafond * 100, 1) if plafond else 0,
                                      "depasse_tva": params.get("tva_active") != "1" and ca_annuel > num(params, "seuil_tva"),
                                      "depasse_plafond": ca_annuel > plafond}
        if a.get("sim") == "facture":
            montant = lire_nombre(a.get("montant", ""), 0.0)
            if montant > 0:
                resultats["facture"] = {"cotisations": round(montant * cotis, 2), "vl": round(montant * vl, 2),
                                        "net": round(montant * (1 - part_charges), 2)}
        if a.get("sim") == "reel":
            ca_sim = lire_nombre(a.get("ca", ""), 0.0)
            dep = lire_nombre(a.get("depenses", ""), 0.0)
            if ca_sim > 0:
                abattement = num(params, "abattement")
                base_micro = ca_sim * (1 - abattement / 100)
                base_reel = max(ca_sim - dep, 0)
                resultats["reel"] = {"base_micro": round(base_micro, 2), "base_reel": round(base_reel, 2),
                                     "ratio": round(dep / ca_sim * 100, 1), "abattement": abattement,
                                     "reel_avantageux": base_reel < base_micro}
        if a.get("sim") == "tva":
            prix = lire_nombre(a.get("prix", ""), 0.0)
            taux = lire_nombre(a.get("taux", "20"), 20.0)
            if prix > 0:
                ht = prix / (1 + taux / 100)
                resultats["tva"] = {"ht": round(ht, 2), "tva": round(prix - ht, 2),
                                    "nouveau_ttc": round(prix * (1 + taux / 100), 2), "taux": taux}
        valeurs = {"net": a.get("net", ""), "heures": a.get("heures", "100"), "charges": a.get("charges", "0"),
                   "montant": a.get("montant", ""), "ca": a.get("ca", "" if not stats["projection"] else str(stats["projection"])),
                   "depenses": a.get("depenses", str(stats["depenses"])), "prix": a.get("prix", ""),
                   "taux": a.get("taux", "20")}
        return render_template("simulateurs.html", r=resultats, v=valeurs, params=params, cotis=cotis, vl=vl,
                               sim=a.get("sim", ""))

    # ------------------------------------------------------------ exports
    @app.route("/exports")
    def exports():
        db = get_db()
        annee = request.args.get("annee", type=int) or date.today().year
        return render_template("exports.html", annee=annee, annees=outils.annees_disponibles(db))

    @app.route("/exports/documents.csv")
    def documents_csv():
        db = get_db()
        annee = request.args.get("annee", type=int) or date.today().year
        return reponse_csv(csv_documents(db, get_params(db), annee), "factures-devis-{}.csv".format(annee))

    @app.route("/exports/archive.zip")
    def archive():
        db = get_db()
        params = get_params(db)
        annee = request.args.get("annee", type=int) or date.today().year
        tampon = io.BytesIO()
        with zipfile.ZipFile(tampon, "w", zipfile.ZIP_DEFLATED) as archive_zip:
            for d in db.execute("SELECT id, numero, type FROM documents WHERE substr(date_emission, 1, 4) = ? "
                                "ORDER BY numero", (str(annee),)).fetchall():
                dossier = {"facture": "factures", "devis": "devis", "avoir": "avoirs"}[d["type"]]
                archive_zip.writestr("{}/{}.pdf".format(dossier, d["numero"]),
                                     r_documents.pdf_du_document(db, params, d["id"]))
            archive_zip.writestr("livre-des-recettes-{}.pdf".format(annee),
                                 pdf.pdf_recettes([dict(r) for r in recettes_de_l_annee(db, annee)], annee, params))
            archive_zip.writestr("livre-des-recettes-{}.csv".format(annee), csv_recettes(db, annee))
            archive_zip.writestr("depenses-{}.pdf".format(annee),
                                 pdf.pdf_depenses([dict(x) for x in depenses_de_l_annee(db, annee)], annee, params))
            archive_zip.writestr("depenses-{}.csv".format(annee), csv_depenses(db, annee))
            archive_zip.writestr("factures-devis-{}.csv".format(annee), csv_documents(db, params, annee))
            for dep in depenses_de_l_annee(db, annee):
                if dep["justificatif"]:
                    chemin = os.path.join(outils.DOSSIER_JUSTIFICATIFS, dep["justificatif"])
                    if os.path.exists(chemin):
                        archive_zip.write(chemin, "justificatifs/" + dep["justificatif"])
        tampon.seek(0)
        return send_file(tampon, mimetype="application/zip", download_name="archive-comptable-{}.zip".format(annee))
