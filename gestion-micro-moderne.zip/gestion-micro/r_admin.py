# -*- coding: utf-8 -*-
"""Routes : tableau de bord, recherche, paramètres, sauvegarde, restauration, connexion, aide."""
import os
import shutil
import sqlite3
import time
from datetime import date

from flask import (abort, flash, redirect, render_template, request, send_file, send_from_directory,
                   session, url_for)
from werkzeug.security import check_password_hash, generate_password_hash

import outils
from outils import PRESETS, get_db, get_params, lire_nombre, set_param

CHAMPS_TEXTE = ["nom", "siret", "adresse", "email", "telephone", "iban", "bic", "site_web",
                "description_activite", "date_creation", "mentions_pied", "assurance_rcpro",
                "periodicite_declaration"]
CHAMPS_NOMBRES = ["taux_tva", "delai_paiement", "acre", "plafond_micro", "seuil_tva", "seuil_tva_majore",
                  "taux_cotisations", "taux_vl", "abattement", "taux_horaire", "taux_interet_legal"]


def enregistrer(app):
    # ------------------------------------------------------------ tableau de bord
    @app.route("/")
    def tableau_de_bord():
        db = get_db()
        params = get_params(db)
        aujourdhui = date.today()
        annee = request.args.get("annee", type=int) or aujourdhui.year
        stats = outils.calcul_stats(db, params, annee)
        conseils = outils.construire_conseils(params, stats, annee)
        actions = outils.a_faire(db, params) if annee == aujourdhui.year else []
        mois_courant = "{}-{:02d}".format(aujourdhui.year, aujourdhui.month)
        ca_mois = db.execute("SELECT COALESCE(SUM(montant), 0) FROM recettes WHERE substr(date_encaissement, 1, 7) = ?",
                             (mois_courant,)).fetchone()[0]
        minutes_mois = db.execute("SELECT COALESCE(SUM(duree_minutes), 0) FROM interventions WHERE "
                                  "substr(date, 1, 7) = ?", (mois_courant,)).fetchone()[0]
        nb_clients = db.execute("SELECT COUNT(*) FROM clients WHERE actif = 1").fetchone()[0]
        contrats_actifs = db.execute("SELECT COUNT(*) FROM contrats WHERE actif = 1").fetchone()[0]
        recurrent = 0.0
        for c in db.execute("SELECT montant, periodicite FROM contrats WHERE actif = 1"):
            recurrent += c["montant"] * {"mensuel": 1, "trimestriel": 1 / 3, "annuel": 1 / 12}.get(c["periodicite"], 1)
        return render_template("tableau_de_bord.html", s=stats, annee=annee, params=params, conseils=conseils,
                               actions=actions, annees=outils.annees_disponibles(db), ca_mois=round(ca_mois, 2),
                               minutes_mois=minutes_mois, nb_clients=nb_clients, contrats_actifs=contrats_actifs,
                               recurrent=round(recurrent, 2))

    # ------------------------------------------------------------ recherche
    @app.route("/recherche")
    def recherche():
        db = get_db()
        q = request.args.get("q", "").strip()
        r = {"clients": [], "documents": [], "interventions": [], "equipements": [], "depenses": []}
        if q:
            motif = "%" + q + "%"
            r["clients"] = db.execute("SELECT * FROM clients WHERE nom LIKE ? OR email LIKE ? OR siren LIKE ? OR "
                                      "telephone LIKE ? OR notes LIKE ? ORDER BY nom LIMIT 30", (motif,) * 5).fetchall()
            r["documents"] = db.execute("SELECT d.*, c.nom AS client_nom FROM documents d JOIN clients c ON "
                                        "c.id = d.client_id WHERE d.numero LIKE ? OR d.objet LIKE ? OR "
                                        "c.nom LIKE ? OR d.reference_client LIKE ? ORDER BY d.date_emission DESC "
                                        "LIMIT 30", (motif,) * 4).fetchall()
            r["interventions"] = db.execute("SELECT i.*, c.nom AS client_nom FROM interventions i JOIN clients c ON "
                                            "c.id = i.client_id WHERE i.titre LIKE ? OR i.description LIKE ? "
                                            "ORDER BY i.date DESC LIMIT 30", (motif,) * 2).fetchall()
            r["equipements"] = db.execute("SELECT e.*, c.nom AS client_nom FROM equipements e JOIN clients c ON "
                                          "c.id = e.client_id WHERE e.nom LIKE ? OR e.ip LIKE ? OR "
                                          "e.numero_serie LIKE ? OR e.marque_modele LIKE ? LIMIT 30",
                                          (motif,) * 4).fetchall()
            r["depenses"] = db.execute("SELECT * FROM depenses WHERE fournisseur LIKE ? OR description LIKE ? "
                                       "ORDER BY date DESC LIMIT 30", (motif,) * 2).fetchall()
        total = sum([len(v) for v in r.values()])
        return render_template("recherche.html", q=q, r=r, total=total)

    # ------------------------------------------------------------ paramètres
    @app.route("/parametres", methods=["GET", "POST"])
    def parametres():
        db = get_db()
        if request.method == "POST":
            creation = request.form.get("date_creation", "").strip()
            if creation != "":
                try:
                    date.fromisoformat(creation)
                except ValueError:
                    flash("Date de début d'activité invalide.", "danger")
                    return redirect(url_for("parametres"))
            for cle in CHAMPS_TEXTE:
                set_param(db, cle, request.form.get(cle, "").strip())
            for cle in CHAMPS_NOMBRES:
                texte = request.form.get(cle, "").strip()
                set_param(db, cle, "" if (cle == "taux_interet_legal" and texte == "")
                          else str(lire_nombre(texte, 0.0)))
            set_param(db, "tva_active", "1" if request.form.get("tva_active") else "0")
            set_param(db, "versement_liberatoire", "1" if request.form.get("versement_liberatoire") else "0")

            logo = request.files.get("logo")
            if request.form.get("supprimer_logo"):
                set_param(db, "logo", "")
            elif logo is not None and logo.filename:
                extension = logo.filename.rsplit(".", 1)[-1].lower() if "." in logo.filename else ""
                if extension in ("png", "jpg", "jpeg"):
                    nom = "logo.{}".format(extension)
                    logo.save(os.path.join(outils.DOSSIER_DATA, nom))
                    set_param(db, "logo", nom)
                else:
                    flash("Logo refusé : formats acceptés PNG ou JPG.", "danger")

            nouveau_mdp = request.form.get("nouveau_mdp", "")
            if request.form.get("supprimer_mdp"):
                set_param(db, "mdp_hash", "")
                session.pop("connecte", None)
                flash("Mot de passe supprimé : l'accès n'est plus protégé.", "info")
            elif nouveau_mdp:
                if len(nouveau_mdp) < 6:
                    flash("Mot de passe trop court (6 caractères minimum), inchangé.", "danger")
                else:
                    set_param(db, "mdp_hash", generate_password_hash(nouveau_mdp))
                    session["connecte"] = True
                    flash("Mot de passe défini.", "ok")
            db.commit()
            flash("Paramètres enregistrés.", "ok")
            return redirect(url_for("parametres"))
        sauvegardes = sorted(os.listdir(outils.DOSSIER_SAUVEGARDES), reverse=True)[:8]
        return render_template("parametres.html", params=get_params(db), presets=PRESETS, sauvegardes=sauvegardes,
                               dossier_data=outils.DOSSIER_DATA)

    @app.route("/parametres/preset", methods=["POST"])
    def parametres_preset():
        db = get_db()
        choix = request.form.get("activite", "")
        if choix not in PRESETS:
            abort(400)
        for cle, valeur in PRESETS[choix].items():
            if cle != "libelle":
                set_param(db, cle, valeur)
        set_param(db, "activite", choix)
        db.commit()
        flash("Valeurs 2026 chargées pour : {}.".format(PRESETS[choix]["libelle"]), "ok")
        return redirect(url_for("parametres"))

    @app.route("/logo")
    def logo():
        params = get_params(get_db())
        if not params.get("logo"):
            abort(404)
        return send_from_directory(outils.DOSSIER_DATA, params["logo"])

    # ------------------------------------------------------------ sauvegarde et restauration
    @app.route("/sauvegarde")
    def sauvegarde():
        copie = os.path.join(outils.DOSSIER_DATA, "sauvegarde-temporaire.db")
        destination = sqlite3.connect(copie)
        get_db().backup(destination)
        destination.close()
        return send_file(copie, as_attachment=True,
                         download_name="sauvegarde-gestion-{}.db".format(date.today().isoformat()))

    @app.route("/restauration", methods=["POST"])
    def restauration():
        fichier = request.files.get("sauvegarde")
        if fichier is None or not fichier.filename:
            flash("Choisir un fichier de sauvegarde (.db).", "danger")
            return redirect(url_for("parametres"))
        temporaire = os.path.join(outils.DOSSIER_DATA, "restauration-temporaire.db")
        fichier.save(temporaire)
        try:
            test = sqlite3.connect(temporaire)
            tables = [t[0] for t in test.execute("SELECT name FROM sqlite_master WHERE type = 'table'")]
            integrite = test.execute("PRAGMA integrity_check").fetchone()[0]
            test.close()
        except sqlite3.DatabaseError:
            os.remove(temporaire)
            flash("Ce fichier n'est pas une base de données valide.", "danger")
            return redirect(url_for("parametres"))
        if "parametres" not in tables or "documents" not in tables or integrite != "ok":
            os.remove(temporaire)
            flash("Ce fichier ne ressemble pas à une sauvegarde de cette application.", "danger")
            return redirect(url_for("parametres"))
        get_db().close()
        sauvegarde_avant = os.path.join(outils.DOSSIER_SAUVEGARDES, "avant-restauration-{}.db".format(int(time.time())))
        shutil.copy(outils.DB_PATH, sauvegarde_avant)
        os.replace(temporaire, outils.DB_PATH)
        outils.init_db()
        session.pop("connecte", None)
        flash("Sauvegarde restaurée. L'ancienne base a été conservée dans data/sauvegardes.", "ok")
        return redirect(url_for("tableau_de_bord"))

    # ------------------------------------------------------------ connexion
    @app.route("/connexion", methods=["GET", "POST"])
    def connexion():
        params = get_params(get_db())
        if not params.get("mdp_hash"):
            return redirect(url_for("tableau_de_bord"))
        if request.method == "POST":
            if check_password_hash(params["mdp_hash"], request.form.get("mdp", "")):
                session["connecte"] = True
                return redirect(url_for("tableau_de_bord"))
            flash("Mot de passe incorrect.", "danger")
        return render_template("connexion.html")

    @app.route("/deconnexion")
    def deconnexion():
        session.pop("connecte", None)
        return redirect(url_for("connexion"))

    # ------------------------------------------------------------ aide
    @app.route("/aide")
    def aide():
        return render_template("aide.html")
