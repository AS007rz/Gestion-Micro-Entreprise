#!/bin/sh
cd "$(dirname "$0")"
if [ ! -d venv ]; then
  echo "Installation la premiere fois, patientez..."
  python3 -m venv venv
  venv/bin/pip install -r requirements.txt
fi
echo "Ouvrir http://127.0.0.1:5000 dans le navigateur"
venv/bin/python app.py
