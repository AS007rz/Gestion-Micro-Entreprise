# -*- coding: utf-8 -*-
"""Routes : interventions (suivi du temps), checklists, modèles, rappels."""
import csv
import io
from datetime import date, timedelta

from flask import Response, abort, flash, redirect, render_template, request, send_file, url_for

import outils
import pdf
from outils import TYPES_INTERVENTION, get_db, get_params, lire_nombre


def lire_duree(texte):
    """'1,5' ou '1.5' = heures ; '1:30' ou '1h30' = 1 h 30. Retourne des minutes."""
    texte = str(texte).strip().lower().replace(" ", "")
    if texte == "":
        return 0
    if ":" in texte or "h" in texte:
        morceaux = texte.replace("h", ":").split(":")
        heures = lire_nombre(morceaux[0], 0.0)
        minutes = lire_nombre(morceaux[1], 0.0) if len(morceaux) > 1 and morceaux[1] != "" else 0.0
        return int(round(heures * 60 + minutes))
    return int(round(lire_nombre(texte, 0.0) * 60))


def enregistrer(app):
    # ------------------------------------------------------------ interventions
    @app.route("/interventions")
    def interventions():
        db = get_db()
        params = get_params(db)
        filtre = request.args.get("filtre", "")
        client_id = request.args.get("client_id", type=int)
        annee = request.args.get("annee", type=int)
        q = request.args.get("q", "").strip()
        requete = ("SELECT i.*, c.nom AS client_nom, c.tarif_horaire FROM interventions i "
                   "JOIN clients c ON c.id = i.client_id WHERE 1 = 1 ")
        args = []
        if filtre == "a_facturer":
            requete += "AND i.statut = 'terminee' AND i.facturable = 1 AND i.document_id IS NULL "
        elif filtre in ("planifiee", "en_cours", "terminee"):
            requete += "AND i.statut = ? "
            args.append(filtre)
        elif filtre == "facturees":
            requete += "AND i.document_id IS NOT NULL "
        if client_id:
            requete += "AND i.client_id = ? "
            args.append(client_id)
        if annee:
            requete += "AND substr(i.date, 1, 4) = ? "
            args.append(str(annee))
        if q:
            requete += "AND (i.titre LIKE ? OR i.description LIKE ? OR c.nom LIKE ?) "
            args.extend(["%" + q + "%"] * 3)
        requete += "ORDER BY i.date DESC, i.id DESC"
        liste = []
        minutes = 0
        valeur = 0.0
        for i in db.execute(requete, args).fetchall():
            d = dict(i)
            d["valeur"] = outils.valeur_intervention(params, i, i)["total"] if i["facturable"] else 0.0
            minutes += i["duree_minutes"] or 0
            valeur += d["valeur"]
            liste.append(d)
        clients = db.execute("SELECT id, nom FROM clients ORDER BY nom").fetchall()
        return render_template("interventions.html", liste=liste, filtre=filtre, client_id=client_id,
                               annee=annee, q=q, clients=clients, minutes=minutes,
                               valeur=round(valeur, 2), annees=outils.annees_disponibles(db))

    @app.route("/interventions/export.csv")
    def interventions_csv():
        db = get_db()
        params = get_params(db)
        tampon = io.StringIO()
        ecrivain = csv.writer(tampon, delimiter=";")
        ecrivain.writerow(["Date", "Client", "Type", "Titre", "Durée (h)", "Statut", "Facturable",
                           "Montant estimé", "Facture"])
        for i in db.execute("SELECT i.*, c.nom AS client_nom, c.tarif_horaire, d.numero AS facture FROM "
                            "interventions i JOIN clients c ON c.id = i.client_id LEFT JOIN documents d ON "
                            "d.id = i.document_id ORDER BY i.date"):
            valeur = outils.valeur_intervention(params, i, i)["total"] if i["facturable"] else 0
            ecrivain.writerow([i["date"], i["client_nom"], i["type"], i["titre"],
                               "{:.2f}".format((i["duree_minutes"] or 0) / 60).replace(".", ","),
                               outils.STATUTS.get(i["statut"], i["statut"]), "oui" if i["facturable"] else "non",
                               "{:.2f}".format(valeur).replace(".", ","), i["facture"] or ""])
        return Response("\ufeff" + tampon.getvalue(), mimetype="text/csv; charset=utf-8",
                        headers={"Content-Disposition": "attachment; filename=interventions.csv"})

    @app.route("/interventions/nouvelle", methods=["GET", "POST"])
    @app.route("/interventions/<int:inter_id>/modifier", methods=["GET", "POST"])
    def intervention_formulaire(inter_id=None):
        db = get_db()
        params = get_params(db)
        inter = None
        if inter_id is not None:
            inter = db.execute("SELECT * FROM interventions WHERE id = ?", (inter_id,)).fetchone()
            if inter is None:
                abort(404)
        clients = db.execute("SELECT id, nom, tarif_horaire FROM clients WHERE actif = 1 ORDER BY nom").fetchall()
        equipements = db.execute("SELECT e.id, e.nom, e.client_id FROM equipements e ORDER BY e.nom").fetchall()
        modeles = db.execute("SELECT * FROM modeles_checklist ORDER BY nom").fetchall()
        if request.method == "POST":
            client_id = request.form.get("client_id", type=int)
            titre = request.form.get("titre", "").strip()
            if not client_id or titre == "":
                flash("Le client et le titre sont obligatoires.", "danger")
                return render_template("intervention_form.html", inter=request.form, clients=clients,
                                       equipements=equipements, modeles=modeles, types=TYPES_INTERVENTION,
                                       nouveau=inter is None, taux_defaut=outils.num(params, "taux_horaire"))
            valeurs = (client_id, request.form.get("date") or date.today().isoformat(),
                       lire_duree(request.form.get("duree", "")), request.form.get("type", ""), titre,
                       request.form.get("description", "").strip(), request.form.get("statut", "terminee"),
                       1 if request.form.get("facturable") else 0,
                       lire_nombre(request.form.get("taux_horaire", ""), 0.0),
                       lire_nombre(request.form.get("forfait", ""), 0.0),
                       lire_nombre(request.form.get("frais_deplacement", ""), 0.0),
                       request.form.get("equipement_id", type=int))
            if inter is None:
                curseur = db.execute(
                    "INSERT INTO interventions (client_id, date, duree_minutes, type, titre, description, statut, "
                    "facturable, taux_horaire, forfait, frais_deplacement, equipement_id) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", valeurs)
                nouvelle_id = curseur.lastrowid
                modele_id = request.form.get("modele_id", type=int)
                if modele_id:
                    modele = db.execute("SELECT * FROM modeles_checklist WHERE id = ?", (modele_id,)).fetchone()
                    if modele is not None:
                        for ligne in modele["elements"].split("\n"):
                            if ligne.strip():
                                db.execute("INSERT INTO intervention_taches (intervention_id, texte) VALUES (?, ?)",
                                           (nouvelle_id, ligne.strip()))
                db.commit()
                flash("Intervention enregistrée.", "ok")
                return redirect(url_for("intervention_voir", inter_id=nouvelle_id))
            db.execute("UPDATE interventions SET client_id=?, date=?, duree_minutes=?, type=?, titre=?, "
                       "description=?, statut=?, facturable=?, taux_horaire=?, forfait=?, frais_deplacement=?, "
                       "equipement_id=? WHERE id=?", valeurs + (inter_id,))
            db.commit()
            flash("Intervention modifiée.", "ok")
            return redirect(url_for("intervention_voir", inter_id=inter_id))
        if inter is None:
            inter = {"client_id": request.args.get("client_id", type=int), "date": date.today().isoformat(),
                     "duree_minutes": 0, "type": "Dépannage à distance", "titre": "", "description": "",
                     "statut": "terminee", "facturable": 1, "taux_horaire": "", "forfait": "",
                     "frais_deplacement": "", "equipement_id": None}
        return render_template("intervention_form.html", inter=inter, clients=clients, equipements=equipements,
                               modeles=modeles, types=TYPES_INTERVENTION, nouveau=inter_id is None,
                               taux_defaut=outils.num(params, "taux_horaire"))

    @app.route("/interventions/<int:inter_id>")
    def intervention_voir(inter_id):
        db = get_db()
        params = get_params(db)
        inter = db.execute("SELECT * FROM interventions WHERE id = ?", (inter_id,)).fetchone()
        if inter is None:
            abort(404)
        client = db.execute("SELECT * FROM clients WHERE id = ?", (inter["client_id"],)).fetchone()
        taches = db.execute("SELECT * FROM intervention_taches WHERE intervention_id = ? ORDER BY id",
                            (inter_id,)).fetchall()
        valeur = outils.valeur_intervention(params, inter, client)
        facture = None
        if inter["document_id"]:
            facture = db.execute("SELECT id, numero FROM documents WHERE id = ?", (inter["document_id"],)).fetchone()
        equipement = None
        if inter["equipement_id"]:
            equipement = db.execute("SELECT * FROM equipements WHERE id = ?", (inter["equipement_id"],)).fetchone()
        faites = len([t for t in taches if t["fait"]])
        return render_template("intervention_voir.html", inter=inter, client=client, taches=taches,
                               valeur=valeur, facture=facture, equipement=equipement, faites=faites)

    @app.route("/interventions/<int:inter_id>/pdf")
    def intervention_pdf(inter_id):
        db = get_db()
        params = get_params(db)
        inter = db.execute("SELECT * FROM interventions WHERE id = ?", (inter_id,)).fetchone()
        if inter is None:
            abort(404)
        client = db.execute("SELECT * FROM clients WHERE id = ?", (inter["client_id"],)).fetchone()
        taches = db.execute("SELECT * FROM intervention_taches WHERE intervention_id = ? ORDER BY id",
                            (inter_id,)).fetchall()
        contenu = pdf.pdf_intervention(dict(inter), dict(client), [dict(t) for t in taches], params)
        return send_file(io.BytesIO(contenu), mimetype="application/pdf",
                         download_name="compte-rendu-{}-{}.pdf".format(inter["date"], inter_id))

    @app.route("/interventions/<int:inter_id>/supprimer", methods=["POST"])
    def intervention_supprimer(inter_id):
        db = get_db()
        inter = db.execute("SELECT * FROM interventions WHERE id = ?", (inter_id,)).fetchone()
        if inter is None:
            abort(404)
        if inter["document_id"]:
            flash("Cette intervention est liée à une facture : suppression impossible.", "danger")
            return redirect(url_for("intervention_voir", inter_id=inter_id))
        db.execute("DELETE FROM interventions WHERE id = ?", (inter_id,))
        db.commit()
        flash("Intervention supprimée.", "ok")
        return redirect(url_for("interventions"))

    @app.route("/interventions/<int:inter_id>/statut", methods=["POST"])
    def intervention_statut(inter_id):
        db = get_db()
        nouveau = request.form.get("statut", "")
        if nouveau not in ("planifiee", "en_cours", "terminee"):
            abort(400)
        db.execute("UPDATE interventions SET statut = ? WHERE id = ?", (nouveau, inter_id))
        db.commit()
        return redirect(url_for("intervention_voir", inter_id=inter_id))

    # ------------------------------------------------------------ checklist
    @app.route("/interventions/<int:inter_id>/taches", methods=["POST"])
    def tache_intervention_ajouter(inter_id):
        db = get_db()
        texte = request.form.get("texte", "").strip()
        if texte:
            db.execute("INSERT INTO intervention_taches (intervention_id, texte) VALUES (?, ?)", (inter_id, texte))
            db.commit()
        return redirect(url_for("intervention_voir", inter_id=inter_id) + "#checklist")

    @app.route("/interventions/taches/<int:tache_id>/basculer", methods=["POST"])
    def tache_intervention_basculer(tache_id):
        db = get_db()
        t = db.execute("SELECT * FROM intervention_taches WHERE id = ?", (tache_id,)).fetchone()
        if t is None:
            abort(404)
        db.execute("UPDATE intervention_taches SET fait = ? WHERE id = ?", (0 if t["fait"] else 1, tache_id))
        db.commit()
        return redirect(url_for("intervention_voir", inter_id=t["intervention_id"]) + "#checklist")

    @app.route("/interventions/taches/<int:tache_id>/supprimer", methods=["POST"])
    def tache_intervention_supprimer(tache_id):
        db = get_db()
        t = db.execute("SELECT * FROM intervention_taches WHERE id = ?", (tache_id,)).fetchone()
        if t is None:
            abort(404)
        db.execute("DELETE FROM intervention_taches WHERE id = ?", (tache_id,))
        db.commit()
        return redirect(url_for("intervention_voir", inter_id=t["intervention_id"]) + "#checklist")

    # ------------------------------------------------------------ facturation des interventions
    @app.route("/interventions/facturer", methods=["POST"])
    def interventions_facturer():
        db = get_db()
        params = get_params(db)
        ids = request.form.getlist("ids", type=int)
        if not ids:
            flash("Cocher au moins une intervention à facturer.", "danger")
            return redirect(request.referrer or url_for("interventions"))
        lignes_inter = []
        for ident in ids:
            i = db.execute("SELECT i.*, c.tarif_horaire FROM interventions i JOIN clients c ON c.id = i.client_id "
                           "WHERE i.id = ?", (ident,)).fetchone()
            if i is None or i["document_id"] or not i["facturable"]:
                flash("Une intervention sélectionnée est déjà facturée ou non facturable.", "danger")
                return redirect(request.referrer or url_for("interventions"))
            lignes_inter.append(i)
        if len(set([i["client_id"] for i in lignes_inter])) > 1:
            flash("Les interventions sélectionnées doivent concerner le même client.", "danger")
            return redirect(request.referrer or url_for("interventions"))
        client = db.execute("SELECT * FROM clients WHERE id = ?", (lignes_inter[0]["client_id"],)).fetchone()
        lignes = []
        for i in sorted(lignes_inter, key=lambda x: x["date"]):
            v = outils.valeur_intervention(params, i, i)
            texte_date = date.fromisoformat(i["date"]).strftime("%d/%m/%Y")
            description = "{} - {}".format(texte_date, i["titre"])
            if i["type"]:
                description += " ({})".format(i["type"])
            if i["forfait"] and i["forfait"] > 0:
                lignes.append((description, "forfait", 1.0, i["forfait"], 0.0))
            elif v["heures"] > 0:
                lignes.append((description, "h", round(v["heures"], 2), v["taux"], 0.0))
            if v["deplacement"] > 0:
                lignes.append(("Frais de déplacement - " + i["titre"], "forfait", 1.0, v["deplacement"], 0.0))
        if not lignes:
            flash("Les interventions sélectionnées n'ont ni durée ni forfait.", "danger")
            return redirect(request.referrer or url_for("interventions"))
        aujourdhui = date.today()
        date_limite = aujourdhui + timedelta(days=outils.delai_client(params, client))
        dates = sorted([i["date"] for i in lignes_inter])
        doc_id, numero = outils.creer_document(
            db, params, "facture", client["id"], lignes, aujourdhui.isoformat(), date_limite.isoformat(),
            objet="Interventions de maintenance informatique", date_prestation=dates[-1])
        for i in lignes_inter:
            db.execute("UPDATE interventions SET document_id = ? WHERE id = ?", (doc_id, i["id"]))
        db.commit()
        flash("Facture {} créée à partir de {} intervention{}.".format(
            numero, len(lignes_inter), "s" if len(lignes_inter) > 1 else ""), "ok")
        return redirect(url_for("document_voir", doc_id=doc_id))

    # ------------------------------------------------------------ modèles de checklist
    @app.route("/modeles", methods=["GET", "POST"])
    def modeles():
        db = get_db()
        if request.method == "POST":
            nom = request.form.get("nom", "").strip()
            elements = "\n".join([l.strip() for l in request.form.get("elements", "").split("\n") if l.strip()])
            if nom == "" or elements == "":
                flash("Le nom et au moins une étape sont obligatoires.", "danger")
                return redirect(url_for("modeles"))
            ident = request.form.get("id", type=int)
            if ident:
                db.execute("UPDATE modeles_checklist SET nom = ?, elements = ? WHERE id = ?", (nom, elements, ident))
                flash("Modèle modifié.", "ok")
            else:
                db.execute("INSERT INTO modeles_checklist (nom, elements) VALUES (?, ?)", (nom, elements))
                flash("Modèle ajouté.", "ok")
            db.commit()
            return redirect(url_for("modeles"))
        modifier = request.args.get("modifier", type=int)
        edition = None
        if modifier:
            edition = db.execute("SELECT * FROM modeles_checklist WHERE id = ?", (modifier,)).fetchone()
        liste = []
        for m in db.execute("SELECT * FROM modeles_checklist ORDER BY nom").fetchall():
            d = dict(m)
            d["etapes"] = [l for l in m["elements"].split("\n") if l]
            liste.append(d)
        return render_template("modeles.html", liste=liste, edition=edition)

    @app.route("/modeles/<int:ident>/supprimer", methods=["POST"])
    def modele_supprimer(ident):
        db = get_db()
        db.execute("DELETE FROM modeles_checklist WHERE id = ?", (ident,))
        db.commit()
        flash("Modèle supprimé.", "ok")
        return redirect(url_for("modeles"))

    # ------------------------------------------------------------ rappels
    @app.route("/taches", methods=["GET", "POST"])
    def taches():
        db = get_db()
        if request.method == "POST":
            titre = request.form.get("titre", "").strip()
            if titre == "":
                flash("Le titre du rappel est obligatoire.", "danger")
            else:
                db.execute("INSERT INTO taches (titre, echeance, client_id) VALUES (?, ?, ?)",
                           (titre, request.form.get("echeance", ""), request.form.get("client_id", type=int)))
                db.commit()
                flash("Rappel ajouté.", "ok")
            return redirect(url_for("taches"))
        afficher_faits = request.args.get("faits") == "1"
        requete = ("SELECT t.*, c.nom AS client_nom FROM taches t LEFT JOIN clients c ON c.id = t.client_id ")
        if not afficher_faits:
            requete += "WHERE t.fait = 0 "
        requete += "ORDER BY t.fait, CASE WHEN t.echeance = '' THEN 1 ELSE 0 END, t.echeance"
        liste = db.execute(requete).fetchall()
        clients = db.execute("SELECT id, nom FROM clients WHERE actif = 1 ORDER BY nom").fetchall()
        return render_template("taches.html", liste=liste, clients=clients, faits=afficher_faits,
                               aujourdhui=date.today().isoformat())

    @app.route("/taches/<int:ident>/basculer", methods=["POST"])
    def tache_basculer(ident):
        db = get_db()
        t = db.execute("SELECT fait FROM taches WHERE id = ?", (ident,)).fetchone()
        if t is None:
            abort(404)
        db.execute("UPDATE taches SET fait = ? WHERE id = ?", (0 if t["fait"] else 1, ident))
        db.commit()
        return redirect(url_for("taches"))

    @app.route("/taches/<int:ident>/supprimer", methods=["POST"])
    def tache_supprimer(ident):
        db = get_db()
        db.execute("DELETE FROM taches WHERE id = ?", (ident,))
        db.commit()
        return redirect(url_for("taches"))
