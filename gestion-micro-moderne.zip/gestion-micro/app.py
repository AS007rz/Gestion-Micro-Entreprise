# -*- coding: utf-8 -*-
"""Gestion de micro-entreprise : point d'entrée de l'application."""
from datetime import date

from flask import Flask, redirect, request, session, url_for

import outils
import r_activite
import r_admin
import r_clients
import r_compta
import r_documents

outils.init_db()

app = Flask(__name__)
app.secret_key = outils.cle_secrete()
app.config["MAX_CONTENT_LENGTH"] = 40 * 1024 * 1024
app.teardown_appcontext(outils.fermer_db)

DERNIERE_SAUVEGARDE = {"jour": ""}


# ---------------------------------------------------------------------------
# Filtres d'affichage
# ---------------------------------------------------------------------------
@app.template_filter("eur")
def filtre_eur(valeur):
    return outils.formater_eur(valeur or 0)


@app.template_filter("date_fr")
def filtre_date_fr(texte):
    if not texte:
        return ""
    try:
        return date.fromisoformat(texte).strftime("%d/%m/%Y")
    except ValueError:
        return texte


@app.template_filter("statut_fr")
def filtre_statut(code):
    return outils.STATUTS.get(code, code)


@app.template_filter("nombre")
def filtre_nombre(valeur):
    return "{:g}".format(valeur).replace(".", ",")


@app.template_filter("heures")
def filtre_heures(minutes):
    minutes = int(minutes or 0)
    return "{} h {:02d}".format(minutes // 60, minutes % 60)


@app.context_processor
def contexte_global():
    db = outils.get_db()
    params = outils.get_params(db)
    auj = date.today().isoformat()
    retards = db.execute("SELECT COUNT(*) FROM documents WHERE type = 'facture' AND statut IN "
                         "('emise', 'partielle') AND date_limite < ?", (auj,)).fetchone()[0]
    rappels = db.execute("SELECT COUNT(*) FROM taches WHERE fait = 0 AND echeance != '' AND echeance <= ?",
                         (auj,)).fetchone()[0]
    return {
        "entreprise": params.get("nom") or "Ma micro-entreprise",
        "logo_present": bool(params.get("logo")),
        "protege": bool(params.get("mdp_hash")),
        "aujourdhui": auj,
        "modes_paiement": outils.MODES_PAIEMENT,
        "badge_relances": retards,
        "badge_rappels": rappels,
        "statuts_doc": outils.STATUTS,
    }


# ---------------------------------------------------------------------------
# Protection par mot de passe (optionnelle) et sauvegarde quotidienne
# ---------------------------------------------------------------------------
@app.before_request
def avant_requete():
    if DERNIERE_SAUVEGARDE["jour"] != date.today().isoformat():
        outils.sauvegarde_auto()
        DERNIERE_SAUVEGARDE["jour"] = date.today().isoformat()
    if request.endpoint in ("static", "connexion"):
        return None
    db = outils.get_db()
    if outils.get_params(db).get("mdp_hash") and not session.get("connecte"):
        return redirect(url_for("connexion"))
    return None


r_admin.enregistrer(app)
r_documents.enregistrer(app)
r_clients.enregistrer(app)
r_activite.enregistrer(app)
r_compta.enregistrer(app)

if __name__ == "__main__":
    # 127.0.0.1 : accessible uniquement depuis cet ordinateur.
    app.run(host="127.0.0.1", port=5000, debug=False)
