# -*- coding: utf-8 -*-
"""Routes : documents (factures, devis, avoirs), paiements, relances, catalogue, contrats."""
import io
from datetime import date, timedelta
from urllib.parse import quote

from flask import abort, flash, redirect, render_template, request, send_file, url_for

import outils
import pdf
from outils import (TYPES_DOC, UNITES, formater_eur, get_db, get_params, lire_nombre, num)


def lignes_depuis_formulaire():
    descriptions = request.form.getlist("description")
    unites = request.form.getlist("unite")
    quantites = request.form.getlist("quantite")
    prix = request.form.getlist("prix")
    remises = request.form.getlist("remise")
    lignes = []
    for i in range(len(descriptions)):
        lignes.append({"description": descriptions[i],
                       "unite": unites[i] if i < len(unites) else "",
                       "quantite": quantites[i] if i < len(quantites) else "1",
                       "prix": prix[i] if i < len(prix) else "0",
                       "remise": remises[i] if i < len(remises) else "0"})
    return lignes


def donnees_formulaire():
    return {"client_id": request.form.get("client_id", type=int),
            "objet": request.form.get("objet", ""), "notes": request.form.get("notes", ""),
            "conditions": request.form.get("conditions", ""),
            "reference_client": request.form.get("reference_client", ""),
            "date_prestation": request.form.get("date_prestation", ""),
            "date_emission": request.form.get("date_emission", ""),
            "date_limite": request.form.get("date_limite", ""),
            "devis_origine_id": request.form.get("devis_origine_id", type=int),
            "facture_origine_id": request.form.get("facture_origine_id", type=int),
            "lignes": lignes_depuis_formulaire()}


def prefill_depuis_document(db, doc_id):
    doc = db.execute("SELECT * FROM documents WHERE id = ?", (doc_id,)).fetchone()
    if doc is None:
        abort(404)
    lignes = []
    for l in db.execute("SELECT * FROM lignes WHERE document_id = ? ORDER BY id", (doc_id,)):
        lignes.append({"description": l["description"], "unite": l["unite"], "quantite": l["quantite"],
                       "prix": l["prix_unitaire"], "remise": l["remise"]})
    return {"client_id": doc["client_id"], "objet": doc["objet"], "notes": doc["notes"],
            "conditions": doc["conditions"], "reference_client": doc["reference_client"],
            "lignes": lignes}


def pdf_du_document(db, params, doc_id):
    """Retourne le PDF (octets) d'un document."""
    doc = db.execute("SELECT * FROM documents WHERE id = ?", (doc_id,)).fetchone()
    client = db.execute("SELECT * FROM clients WHERE id = ?", (doc["client_id"],)).fetchone()
    t = outils.totaux_document(db, doc_id, params)
    donnees = dict(doc)
    if doc["facture_origine_id"]:
        o = db.execute("SELECT numero FROM documents WHERE id = ?", (doc["facture_origine_id"],)).fetchone()
        donnees["origine_numero"] = o["numero"] if o else ""
    if doc["devis_origine_id"]:
        o = db.execute("SELECT numero FROM documents WHERE id = ?", (doc["devis_origine_id"],)).fetchone()
        donnees["devis_numero"] = o["numero"] if o else ""
    return pdf.pdf_document(donnees, [dict(l) for l in t["lignes"]], dict(client), params, t,
                            outils.nature_operation(params))


def texte_relance(niveau, doc, client, params, reste, jours, penalite):
    nom = params.get("nom") or "Votre prestataire"
    montant = formater_eur(reste).replace("\u00a0", " ")
    base = "Bonjour,\n\n"
    if niveau == 1:
        corps = ("Sauf erreur de ma part, la facture {numero} du {date} d'un montant de {montant} "
                 "n'a pas encore été réglée (échéance dépassée de {jours} jour{s}).\n\n"
                 "Pourriez-vous procéder au règlement ou me signaler un éventuel problème ? "
                 "Si le paiement a été fait entre-temps, merci de ne pas tenir compte de ce message.")
    elif niveau == 2:
        corps = ("Malgré mon précédent rappel, la facture {numero} du {date} d'un montant de {montant} "
                 "reste impayée ({jours} jour{s} de retard).\n\n"
                 "Je vous remercie de la régler sous 8 jours. Des pénalités de retard et une indemnité "
                 "forfaitaire de recouvrement de 40 € sont applicables conformément aux conditions "
                 "indiquées sur la facture.")
    else:
        corps = ("La facture {numero} du {date} d'un montant de {montant} demeure impayée malgré mes "
                 "relances ({jours} jour{s} de retard).\n\n"
                 "Je vous mets en demeure de la régler sous 8 jours, faute de quoi je me réserverai le "
                 "droit d'engager les démarches de recouvrement. Les pénalités de retard et l'indemnité "
                 "forfaitaire de 40 € restent dues.")
    texte = base + corps.format(numero=doc["numero"], date=doc["date_emission"][8:10] + "/" +
                                doc["date_emission"][5:7] + "/" + doc["date_emission"][:4],
                                montant=montant, jours=jours, s="s" if jours > 1 else "")
    if penalite > 0 and niveau > 1:
        texte += "\n\nPénalités de retard estimées à ce jour : {}.".format(
            formater_eur(penalite).replace("\u00a0", " "))
    texte += "\n\nCordialement,\n" + nom
    return texte


def enregistrer(app):
    # -------------------------------------------------------------- liste
    @app.route("/documents")
    def documents():
        db = get_db()
        params = get_params(db)
        aujourdhui = date.today().isoformat()
        type_doc = request.args.get("type", "")
        statut = request.args.get("statut", "")
        client_id = request.args.get("client_id", type=int)
        annee = request.args.get("annee", type=int)
        q = request.args.get("q", "").strip()
        conditions = []
        args = []
        if type_doc in TYPES_DOC:
            conditions.append("d.type = ?")
            args.append(type_doc)
        if statut == "retard":
            conditions.append("d.type = 'facture' AND d.statut IN ('emise', 'partielle') AND d.date_limite < ?")
            args.append(aujourdhui)
        elif statut:
            conditions.append("d.statut = ?")
            args.append(statut)
        if client_id:
            conditions.append("d.client_id = ?")
            args.append(client_id)
        if annee:
            conditions.append("substr(d.date_emission, 1, 4) = ?")
            args.append(str(annee))
        if q:
            conditions.append("(d.numero LIKE ? OR d.objet LIKE ? OR c.nom LIKE ? OR d.reference_client LIKE ?)")
            args.extend(["%" + q + "%"] * 4)
        requete = ("SELECT d.*, c.nom AS client_nom, "
                   "(SELECT COALESCE(SUM(ROUND(l.quantite * l.prix_unitaire * (1 - l.remise / 100.0), 2)), 0) "
                   " FROM lignes l WHERE l.document_id = d.id) AS total_ht, "
                   "(SELECT COALESCE(SUM(montant), 0) FROM paiements WHERE document_id = d.id) AS paye "
                   "FROM documents d JOIN clients c ON c.id = d.client_id ")
        if conditions:
            requete += "WHERE " + " AND ".join(conditions) + " "
        requete += "ORDER BY d.date_emission DESC, d.numero DESC"
        liste = []
        total_ht = 0.0
        for ligne in db.execute(requete, args).fetchall():
            d = dict(ligne)
            d["en_retard"] = d["type"] == "facture" and d["statut"] in ("emise", "partielle") \
                and d["date_limite"] < aujourdhui
            d["expire"] = d["type"] == "devis" and d["statut"] == "envoye" and d["date_limite"] < aujourdhui
            if d["type"] != "avoir":
                total_ht += d["total_ht"]
            else:
                total_ht -= d["total_ht"]
            liste.append(d)
        clients = db.execute("SELECT id, nom FROM clients ORDER BY nom").fetchall()
        return render_template("documents.html", documents=liste, type_doc=type_doc, statut=statut,
                               client_id=client_id, annee=annee, q=q, clients=clients,
                               total_ht=round(total_ht, 2), annees=outils.annees_disponibles(db))

    # -------------------------------------------------------------- création
    @app.route("/documents/nouveau", methods=["GET", "POST"])
    def document_nouveau():
        db = get_db()
        params = get_params(db)
        type_doc = request.values.get("type", "facture")
        if type_doc not in TYPES_DOC:
            abort(400)
        clients = db.execute("SELECT * FROM clients WHERE actif = 1 ORDER BY nom").fetchall()
        catalogue = db.execute("SELECT * FROM catalogue WHERE actif = 1 ORDER BY nom").fetchall()

        if request.method == "POST":
            p = donnees_formulaire()
            lignes = []
            for l in p["lignes"]:
                if l["description"].strip() != "":
                    lignes.append((l["description"].strip(), l["unite"], lire_nombre(l["quantite"], 1.0),
                                   lire_nombre(l["prix"], 0.0),
                                   min(max(lire_nombre(l["remise"], 0.0), 0.0), 100.0)))
            if not p["client_id"] or not lignes:
                flash("Choisir un client et saisir au moins une ligne.", "danger")
                return render_template("document_form.html", type_doc=type_doc, p=p, clients=clients,
                                       catalogue=catalogue, unites=UNITES)
            client = db.execute("SELECT * FROM clients WHERE id = ?", (p["client_id"],)).fetchone()
            date_emission = p["date_emission"] or date.today().isoformat()
            if type_doc == "devis":
                delai = 30
            else:
                delai = outils.delai_client(params, client)
            date_limite = p["date_limite"] or (date.fromisoformat(date_emission) + timedelta(days=delai)).isoformat()
            doc_id, numero = outils.creer_document(
                db, params, type_doc, p["client_id"], lignes, date_emission, date_limite,
                p["objet"].strip(), p["notes"].strip(), devis_origine_id=p["devis_origine_id"],
                facture_origine_id=p["facture_origine_id"], reference_client=p["reference_client"].strip(),
                date_prestation=p["date_prestation"], conditions=p["conditions"].strip())
            if p["devis_origine_id"]:
                db.execute("UPDATE documents SET statut = 'accepte' WHERE id = ? AND type = 'devis'",
                           (p["devis_origine_id"],))
            if p["facture_origine_id"]:
                outils.recalculer_statut(db, params, p["facture_origine_id"])
            db.commit()
            flash("{} {} créé.".format(TYPES_DOC[type_doc], numero), "ok")
            if type_doc == "facture":
                stats = outils.calcul_stats(db, params, date.today().year)
                for niveau, texte in stats["alertes"][:2]:
                    flash(texte, "attention" if niveau == "attention" else "danger")
            return redirect(url_for("document_voir", doc_id=doc_id))

        aujourdhui = date.today()
        client_id = request.args.get("client_id", type=int)
        delai = int(num(params, "delai_paiement") or 30)
        p = {"client_id": client_id, "objet": "", "notes": "", "conditions": "", "reference_client": "",
             "date_prestation": "", "date_emission": aujourdhui.isoformat(),
             "date_limite": (aujourdhui + timedelta(days=30 if type_doc == "devis" else delai)).isoformat(),
             "devis_origine_id": None, "facture_origine_id": None,
             "lignes": [{"description": "", "unite": "", "quantite": 1, "prix": "", "remise": 0}]}
        copie = request.args.get("copie", type=int)
        devis = request.args.get("devis", type=int)
        facture = request.args.get("facture", type=int)
        if copie:
            p.update(prefill_depuis_document(db, copie))
        if devis and type_doc == "facture":
            p.update(prefill_depuis_document(db, devis))
            p["devis_origine_id"] = devis
        if facture and type_doc == "avoir":
            p.update(prefill_depuis_document(db, facture))
            p["facture_origine_id"] = facture
            p["objet"] = "Avoir - " + p["objet"] if p["objet"] else "Avoir"
        return render_template("document_form.html", type_doc=type_doc, p=p, clients=clients,
                               catalogue=catalogue, unites=UNITES)

    # -------------------------------------------------------------- fiche
    @app.route("/documents/<int:doc_id>")
    def document_voir(doc_id):
        db = get_db()
        params = get_params(db)
        doc = db.execute("SELECT * FROM documents WHERE id = ?", (doc_id,)).fetchone()
        if doc is None:
            abort(404)
        client = db.execute("SELECT * FROM clients WHERE id = ?", (doc["client_id"],)).fetchone()
        t = outils.totaux_document(db, doc_id, params)
        devis_origine = None
        if doc["devis_origine_id"]:
            devis_origine = db.execute("SELECT id, numero FROM documents WHERE id = ?",
                                       (doc["devis_origine_id"],)).fetchone()
        facture_origine = None
        if doc["facture_origine_id"]:
            facture_origine = db.execute("SELECT id, numero FROM documents WHERE id = ?",
                                         (doc["facture_origine_id"],)).fetchone()
        factures_issues = db.execute("SELECT id, numero FROM documents WHERE devis_origine_id = ?",
                                     (doc_id,)).fetchall()
        interventions = db.execute("SELECT id, titre, date FROM interventions WHERE document_id = ?",
                                   (doc_id,)).fetchall()
        aujourdhui = date.today().isoformat()
        en_retard = doc["type"] == "facture" and doc["statut"] in ("emise", "partielle") \
            and doc["date_limite"] < aujourdhui and t["reste"] > 0
        sujet = "{} {}".format(TYPES_DOC[doc["type"]], doc["numero"])
        corps = ("Bonjour,\n\nVeuillez trouver ci-joint {} {} d'un montant de {}.\n\n"
                 "Cordialement,\n{}").format(
            "la facture" if doc["type"] == "facture" else ("le devis" if doc["type"] == "devis" else "l'avoir"),
            doc["numero"], formater_eur(t["ttc"]).replace("\u00a0", " "), params.get("nom") or "")
        lien_mail = "mailto:{}?subject={}&body={}".format(quote(client["email"] or ""), quote(sujet), quote(corps))
        return render_template("document_voir.html", doc=doc, client=client, t=t, params=params,
                               devis_origine=devis_origine, facture_origine=facture_origine,
                               factures_issues=factures_issues, interventions=interventions,
                               en_retard=en_retard, lien_mail=lien_mail)

    @app.route("/documents/<int:doc_id>/pdf")
    def document_pdf(doc_id):
        db = get_db()
        params = get_params(db)
        doc = db.execute("SELECT * FROM documents WHERE id = ?", (doc_id,)).fetchone()
        if doc is None:
            abort(404)
        contenu = pdf_du_document(db, params, doc_id)
        return send_file(io.BytesIO(contenu), mimetype="application/pdf", download_name=doc["numero"] + ".pdf")

    # -------------------------------------------------------------- paiements
    @app.route("/documents/<int:doc_id>/payer", methods=["POST"])
    def document_payer(doc_id):
        db = get_db()
        params = get_params(db)
        doc = db.execute("SELECT * FROM documents WHERE id = ?", (doc_id,)).fetchone()
        if doc is None or doc["type"] != "facture" or doc["statut"] not in ("emise", "partielle"):
            abort(400)
        t = outils.totaux_document(db, doc_id, params)
        montant = lire_nombre(request.form.get("montant", ""), t["reste"])
        if montant <= 0 or montant > t["reste"] + 0.005:
            flash("Montant invalide : le reste à payer est de {}.".format(formater_eur(t["reste"])), "danger")
            return redirect(url_for("document_voir", doc_id=doc_id))
        date_p = request.form.get("date_paiement") or date.today().isoformat()
        outils.enregistrer_paiement(db, params, doc_id, date_p, round(montant, 2),
                                    request.form.get("mode_paiement", ""), request.form.get("reference", "").strip())
        db.commit()
        flash("Paiement enregistré et ajouté au livre des recettes.", "ok")
        return redirect(url_for("document_voir", doc_id=doc_id))

    @app.route("/paiements/<int:paiement_id>/supprimer", methods=["POST"])
    def paiement_supprimer(paiement_id):
        db = get_db()
        params = get_params(db)
        p = db.execute("SELECT * FROM paiements WHERE id = ?", (paiement_id,)).fetchone()
        if p is None:
            abort(404)
        db.execute("DELETE FROM recettes WHERE paiement_id = ?", (paiement_id,))
        db.execute("DELETE FROM paiements WHERE id = ?", (paiement_id,))
        outils.recalculer_statut(db, params, p["document_id"])
        db.commit()
        flash("Paiement supprimé, recette retirée du livre.", "ok")
        return redirect(url_for("document_voir", doc_id=p["document_id"]))

    @app.route("/documents/<int:doc_id>/rembourser", methods=["POST"])
    def avoir_rembourser(doc_id):
        db = get_db()
        params = get_params(db)
        avoir = db.execute("SELECT * FROM documents WHERE id = ? AND type = 'avoir'", (doc_id,)).fetchone()
        if avoir is None or avoir["statut"] != "emis" or not avoir["facture_origine_id"]:
            abort(400)
        facture_id = avoir["facture_origine_id"]
        t = outils.totaux_document(db, facture_id, params)
        a_rembourser = round(min(outils.montants_document(db, doc_id, params)[3], t["paye"]), 2)
        if a_rembourser <= 0:
            flash("Rien à rembourser : la facture d'origine n'a pas été payée.", "danger")
            return redirect(url_for("document_voir", doc_id=doc_id))
        date_p = request.form.get("date_paiement") or date.today().isoformat()
        outils.enregistrer_paiement(db, params, facture_id, date_p, -a_rembourser,
                                    request.form.get("mode_paiement", ""), "Remboursement " + avoir["numero"])
        db.execute("UPDATE documents SET statut = 'rembourse' WHERE id = ?", (doc_id,))
        db.commit()
        flash("Remboursement enregistré (recette négative au livre des recettes).", "ok")
        return redirect(url_for("document_voir", doc_id=doc_id))

    # -------------------------------------------------------------- statuts
    @app.route("/documents/<int:doc_id>/statut", methods=["POST"])
    def document_statut(doc_id):
        db = get_db()
        doc = db.execute("SELECT * FROM documents WHERE id = ?", (doc_id,)).fetchone()
        if doc is None:
            abort(404)
        nouveau = request.form.get("statut", "")
        if doc["type"] == "facture":
            autorises = ["annulee"] if doc["statut"] == "emise" else []
        elif doc["type"] == "devis":
            autorises = ["envoye", "accepte", "refuse"]
        else:
            autorises = []
        if nouveau not in autorises:
            abort(400)
        db.execute("UPDATE documents SET statut = ? WHERE id = ?", (nouveau, doc_id))
        if nouveau == "annulee":
            db.execute("UPDATE interventions SET document_id = NULL WHERE document_id = ?", (doc_id,))
        db.commit()
        flash("Statut mis à jour.", "ok")
        return redirect(url_for("document_voir", doc_id=doc_id))

    @app.route("/documents/<int:doc_id>/supprimer", methods=["POST"])
    def document_supprimer(doc_id):
        db = get_db()
        doc = db.execute("SELECT * FROM documents WHERE id = ?", (doc_id,)).fetchone()
        if doc is None:
            abort(404)
        if doc["type"] != "devis":
            flash("Une facture ou un avoir ne se supprime pas : annuler la facture à la place.", "danger")
            return redirect(url_for("document_voir", doc_id=doc_id))
        db.execute("UPDATE documents SET devis_origine_id = NULL WHERE devis_origine_id = ?", (doc_id,))
        db.execute("DELETE FROM documents WHERE id = ?", (doc_id,))
        db.commit()
        flash("Devis supprimé.", "ok")
        return redirect(url_for("documents", type="devis"))

    # -------------------------------------------------------------- relances
    @app.route("/relances")
    def relances():
        db = get_db()
        params = get_params(db)
        aujourdhui = date.today()
        taux_legal = num(params, "taux_interet_legal")
        liste = []
        total = 0.0
        for d in db.execute("SELECT d.*, c.nom AS client_nom, c.email AS client_email FROM documents d "
                            "JOIN clients c ON c.id = d.client_id WHERE d.type = 'facture' AND "
                            "d.statut IN ('emise', 'partielle') AND d.date_limite < ? "
                            "ORDER BY d.date_limite", (aujourdhui.isoformat(),)).fetchall():
            t = outils.totaux_document(db, d["id"], params)
            if t["reste"] <= 0:
                continue
            jours = (aujourdhui - date.fromisoformat(d["date_limite"])).days
            niveau = 1 if jours < 15 else (2 if jours < 30 else 3)
            niveau = max(niveau, min(3, d["nb_relances"] + 1)) if d["nb_relances"] else niveau
            interets = round(t["reste"] * 3 * taux_legal / 100 * jours / 365, 2) if taux_legal > 0 else 0.0
            penalite = round(interets + 40, 2) if niveau > 1 else interets
            texte = texte_relance(niveau, d, d, params, t["reste"], jours, penalite)
            sujet = "Facture {} - relance".format(d["numero"])
            lien = "mailto:{}?subject={}&body={}".format(quote(d["client_email"] or ""), quote(sujet), quote(texte))
            total += t["reste"]
            liste.append({"doc": d, "reste": t["reste"], "jours": jours, "niveau": niveau,
                          "penalite": penalite, "texte": texte, "lien_mail": lien})
        return render_template("relances.html", relances=liste, total=round(total, 2), taux_legal=taux_legal)

    @app.route("/relances/<int:doc_id>/marquer", methods=["POST"])
    def relance_marquer(doc_id):
        db = get_db()
        db.execute("UPDATE documents SET derniere_relance = ?, nb_relances = nb_relances + 1 WHERE id = ?",
                   (date.today().isoformat(), doc_id))
        db.commit()
        flash("Relance enregistrée.", "ok")
        return redirect(url_for("relances"))

    # -------------------------------------------------------------- catalogue
    @app.route("/catalogue", methods=["GET", "POST"])
    def catalogue():
        db = get_db()
        if request.method == "POST":
            nom = request.form.get("nom", "").strip()
            if nom == "":
                flash("Le nom de la prestation est obligatoire.", "danger")
                return redirect(url_for("catalogue"))
            valeurs = (nom, request.form.get("description", "").strip(), request.form.get("unite", ""),
                       lire_nombre(request.form.get("prix", ""), 0.0))
            ident = request.form.get("id", type=int)
            if ident:
                db.execute("UPDATE catalogue SET nom=?, description=?, unite=?, prix=? WHERE id=?",
                           valeurs + (ident,))
                flash("Prestation modifiée.", "ok")
            else:
                db.execute("INSERT INTO catalogue (nom, description, unite, prix) VALUES (?, ?, ?, ?)", valeurs)
                flash("Prestation ajoutée.", "ok")
            db.commit()
            return redirect(url_for("catalogue"))
        modifier = request.args.get("modifier", type=int)
        edition = None
        if modifier:
            edition = db.execute("SELECT * FROM catalogue WHERE id = ?", (modifier,)).fetchone()
        liste = db.execute("SELECT * FROM catalogue WHERE actif = 1 ORDER BY nom").fetchall()
        return render_template("catalogue.html", liste=liste, edition=edition, unites=UNITES)

    @app.route("/catalogue/<int:ident>/supprimer", methods=["POST"])
    def catalogue_supprimer(ident):
        db = get_db()
        db.execute("UPDATE catalogue SET actif = 0 WHERE id = ?", (ident,))
        db.commit()
        flash("Prestation retirée du catalogue.", "ok")
        return redirect(url_for("catalogue"))

    # -------------------------------------------------------------- contrats
    @app.route("/contrats")
    def contrats():
        db = get_db()
        aujourdhui = date.today().isoformat()
        liste = []
        annuel = 0.0
        for c in db.execute("SELECT c.*, cl.nom AS client_nom FROM contrats c JOIN clients cl ON "
                            "cl.id = c.client_id ORDER BY c.actif DESC, c.prochaine_echeance").fetchall():
            d = dict(c)
            facteur = {"mensuel": 12, "trimestriel": 4, "annuel": 1}.get(c["periodicite"], 1)
            d["annualise"] = round(c["montant"] * facteur, 2)
            d["a_facturer"] = bool(c["actif"]) and c["prochaine_echeance"] <= aujourdhui
            if c["actif"]:
                annuel += d["annualise"]
            liste.append(d)
        return render_template("contrats.html", contrats=liste, annuel=round(annuel, 2))

    @app.route("/contrats/nouveau", methods=["GET", "POST"])
    @app.route("/contrats/<int:contrat_id>/modifier", methods=["GET", "POST"])
    def contrat_formulaire(contrat_id=None):
        db = get_db()
        contrat = None
        if contrat_id is not None:
            contrat = db.execute("SELECT * FROM contrats WHERE id = ?", (contrat_id,)).fetchone()
            if contrat is None:
                abort(404)
        clients = db.execute("SELECT id, nom FROM clients WHERE actif = 1 ORDER BY nom").fetchall()
        if request.method == "POST":
            client_id = request.form.get("client_id", type=int)
            nom = request.form.get("nom", "").strip()
            montant = lire_nombre(request.form.get("montant", ""), 0.0)
            echeance = request.form.get("prochaine_echeance", "")
            if not client_id or nom == "" or montant <= 0 or echeance == "":
                flash("Client, nom, montant et prochaine échéance sont obligatoires.", "danger")
                return render_template("contrat_form.html", contrat=request.form, clients=clients)
            valeurs = (client_id, nom, request.form.get("description", "").strip(), montant,
                       request.form.get("periodicite", "mensuel"), echeance,
                       request.form.get("date_debut", ""), request.form.get("date_fin", ""),
                       1 if request.form.get("actif") else 0, request.form.get("notes", "").strip())
            if contrat is None:
                db.execute("INSERT INTO contrats (client_id, nom, description, montant, periodicite, "
                           "prochaine_echeance, date_debut, date_fin, actif, notes) "
                           "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", valeurs)
                flash("Contrat ajouté.", "ok")
            else:
                db.execute("UPDATE contrats SET client_id=?, nom=?, description=?, montant=?, periodicite=?, "
                           "prochaine_echeance=?, date_debut=?, date_fin=?, actif=?, notes=? WHERE id=?",
                           valeurs + (contrat_id,))
                flash("Contrat modifié.", "ok")
            db.commit()
            return redirect(url_for("contrats"))
        if contrat is None:
            contrat = {"client_id": request.args.get("client_id", type=int), "nom": "Maintenance informatique",
                       "description": "", "montant": "", "periodicite": "mensuel",
                       "prochaine_echeance": date.today().isoformat(), "date_debut": date.today().isoformat(),
                       "date_fin": "", "actif": 1, "notes": ""}
        return render_template("contrat_form.html", contrat=contrat, clients=clients)

    @app.route("/contrats/<int:contrat_id>/facturer", methods=["POST"])
    def contrat_facturer(contrat_id):
        db = get_db()
        params = get_params(db)
        c = db.execute("SELECT * FROM contrats WHERE id = ?", (contrat_id,)).fetchone()
        if c is None or not c["actif"]:
            abort(400)
        client = db.execute("SELECT * FROM clients WHERE id = ?", (c["client_id"],)).fetchone()
        echeance = date.fromisoformat(c["prochaine_echeance"])
        pas = {"mensuel": 1, "trimestriel": 3, "annuel": 12}.get(c["periodicite"], 1)
        fin_periode = outils.ajouter_mois(echeance, pas) - timedelta(days=1)
        if c["periodicite"] == "mensuel":
            periode = "{} {}".format(outils.MOIS[echeance.month - 1], echeance.year)
        else:
            periode = "du {} au {}".format(echeance.strftime("%d/%m/%Y"), fin_periode.strftime("%d/%m/%Y"))
        description = "{} - {}".format(c["nom"], periode)
        if c["description"]:
            description += "\n" + c["description"]
        aujourdhui = date.today()
        date_limite = aujourdhui + timedelta(days=outils.delai_client(params, client))
        doc_id, numero = outils.creer_document(
            db, params, "facture", c["client_id"],
            [(description, "forfait", 1.0, c["montant"], 0.0)], aujourdhui.isoformat(), date_limite.isoformat(),
            objet=c["nom"], date_prestation=echeance.isoformat(), contrat_id=contrat_id)
        db.execute("UPDATE contrats SET prochaine_echeance = ? WHERE id = ?",
                   (outils.ajouter_mois(echeance, pas).isoformat(), contrat_id))
        db.commit()
        flash("Facture {} créée. Prochaine échéance du contrat : {}.".format(
            numero, outils.ajouter_mois(echeance, pas).strftime("%d/%m/%Y")), "ok")
        return redirect(url_for("document_voir", doc_id=doc_id))

    @app.route("/contrats/<int:contrat_id>/supprimer", methods=["POST"])
    def contrat_supprimer(contrat_id):
        db = get_db()
        db.execute("UPDATE documents SET contrat_id = NULL WHERE contrat_id = ?", (contrat_id,))
        db.execute("DELETE FROM contrats WHERE id = ?", (contrat_id,))
        db.commit()
        flash("Contrat supprimé.", "ok")
        return redirect(url_for("contrats"))
