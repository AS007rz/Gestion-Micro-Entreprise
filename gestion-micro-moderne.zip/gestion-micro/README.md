# Gestion micro-entreprise (local) - version complète

Site de gestion qui tourne uniquement sur ton ordinateur (adresse 127.0.0.1).
Pensé pour une micro-entreprise de maintenance, dépannage et supervision réseau.

## Lancer

Prérequis : Python 3.9 ou plus.

- Windows : double-clic sur `lancer.bat`
- Linux / macOS : `./lancer.sh`

Puis ouvrir http://127.0.0.1:5000 (le .bat l'ouvre tout seul).
La première fois, le script crée un environnement `venv` et installe Flask et reportlab.
Arrêt : Ctrl+C dans la fenêtre du terminal. Ressources : quelques dizaines de Mo de RAM,
rien ne tourne quand le terminal est fermé.

## Fonctionnalités

Pilotage
- Tableau de bord : règle des plafonds (micro et TVA), CA encaissé et en attente, rythme maximal par
  mois, projection, estimation des cotisations, trésorerie nette, liste « À faire »
- Rappels avec échéances, recherche globale

Facturation
- Factures, devis, avoirs en PDF (logo, remises par ligne, unités, mentions micro-entreprise)
- Devis transformé en facture, duplication, annulation (numérotation continue)
- Paiements partiels et acomptes, remboursement d'avoir, statuts automatiques
- Relances de paiement avec textes prêts (rappel, relance, mise en demeure) et pénalités estimées
- Contrats de maintenance récurrents (facturation de l'échéance en un clic)
- Catalogue de prestations (ajout en un clic dans les factures)

Activité
- Interventions avec chronomètre, taux horaire, forfait, frais de déplacement
- Checklists par modèle (migration Linux, mise à jour, transfert de données, dépannage réseau, supervision)
- Compte-rendu d'intervention en PDF pour le client
- Facturation d'une ou plusieurs interventions en une facture
- Fiche client : historique, impayés, CA, parc informatique (équipements, IP, garanties)

Comptabilité
- Livre des recettes (PDF, CSV), alimenté automatiquement par les paiements
- Dépenses avec justificatifs (PDF, images) et catégories
- Déclarations URSSAF mensuelles ou trimestrielles : échéances, cotisations estimées, suivi déclaré / payé
- Rapports : CA par mois (N et N-1), par client, temps par type, délai de paiement, dépendance client
- Simulateurs : tarif horaire cible, net d'une facture, micro ou réel, passage à la TVA
- Archive annuelle ZIP pour un comptable ou un contrôle

Outil
- Sauvegarde automatique quotidienne (30 jours), sauvegarde manuelle, restauration
- Mot de passe optionnel, thème sombre automatique

## Premiers pas

1. Paramètres : nom, SIRET, adresse, date de début d'activité, IBAN, logo.
   Charger les valeurs 2026 pour ton type d'activité.
2. Catalogue : adapter les tarifs d'exemple (ils sont fictifs).
3. Clients, puis interventions et factures.

## Données

Tout est dans le dossier `data` : base `gestion.db`, `justificatifs/`, `sauvegardes/`, logo.
Pour changer de PC ou sauvegarder : copier ce dossier entier. Conserver factures et livre des
recettes 10 ans : sauvegarder aussi hors du PC.

## Points d'attention

- Les plafonds, seuils de TVA et taux 2026 sont préremplis mais à vérifier sur
  autoentrepreneur.urssaf.fr et service-public.fr (modifiables dans Paramètres).
- BIC ou BNC dépend de l'activité déclarée à l'immatriculation.
- Les estimations (cotisations, impôt, pénalités) sont indicatives.
- Le taux d'intérêt légal est à renseigner pour estimer les pénalités de retard.
- Facturation électronique : réforme échelonnée à partir de septembre 2026. L'outil produit des
  PDF classiques, à surveiller quand l'échéance approche pour les micro-entreprises.
- Ne pas stocker de mots de passe clients dans les notes.
