# -*- coding: utf-8 -*-
"""Génération des PDF avec reportlab."""
import os
from datetime import date
from io import BytesIO
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.lib.utils import ImageReader
from reportlab.platypus import Image, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

import outils

ENCRE = colors.HexColor("#16222b")
ACCENT = colors.HexColor("#0d6e6e")
GRIS = colors.HexColor("#5b6770")
TRAIT = colors.HexColor("#d5dcda")
FOND = colors.HexColor("#eef3f2")

NORMAL = ParagraphStyle("normal", fontName="Helvetica", fontSize=9.5, leading=13, textColor=ENCRE)
PETIT = ParagraphStyle("petit", fontName="Helvetica", fontSize=8, leading=11, textColor=GRIS)
TITRE = ParagraphStyle("titre", fontName="Helvetica-Bold", fontSize=22, leading=26, textColor=ACCENT)
DROITE = ParagraphStyle("droite", parent=NORMAL, alignment=2)
GRAS = ParagraphStyle("gras", parent=NORMAL, fontName="Helvetica-Bold")
SOUS_TITRE = ParagraphStyle("sous", parent=NORMAL, fontName="Helvetica-Bold", fontSize=11, leading=15,
                            textColor=ACCENT)


def eur(valeur):
    return "{:,.2f}".format(valeur).replace(",", " ").replace(".", ",") + " €"


def date_fr(texte):
    if not texte:
        return ""
    try:
        return date.fromisoformat(texte).strftime("%d/%m/%Y")
    except ValueError:
        return texte


def nb(valeur):
    return "{:g}".format(valeur).replace(".", ",")


def texte_multiligne(lignes, style=NORMAL):
    morceaux = []
    for ligne in lignes:
        if ligne:
            morceaux.append(escape(str(ligne)).replace("\n", "<br/>"))
    return Paragraph("<br/>".join(morceaux), style)


def logo(params):
    nom = params.get("logo", "")
    if not nom:
        return None
    chemin = os.path.join(outils.DOSSIER_DATA, nom)
    if not os.path.exists(chemin):
        return None
    try:
        largeur, hauteur = ImageReader(chemin).getSize()
        echelle = min(18 * mm / hauteur, 55 * mm / largeur)
        image = Image(chemin, width=largeur * echelle, height=hauteur * echelle)
        image.hAlign = "LEFT"
        return image
    except Exception:
        return None


def pied_de_page(params):
    def dessiner(canvas, document):
        canvas.saveState()
        canvas.setFont("Helvetica", 7.5)
        canvas.setFillColor(GRIS)
        ligne1 = [params.get("nom") or "Entrepreneur individuel"]
        if params.get("siret"):
            ligne1.append("SIRET " + params["siret"])
        if params.get("email"):
            ligne1.append(params["email"])
        canvas.drawCentredString(A4[0] / 2, 12 * mm, "  -  ".join(ligne1))
        if params.get("assurance_rcpro"):
            canvas.drawCentredString(A4[0] / 2, 8.5 * mm, "Assurance : " + params["assurance_rcpro"])
        canvas.drawRightString(A4[0] - 18 * mm, 8.5 * mm, "Page {}".format(canvas.getPageNumber()))
        canvas.restoreState()
    return dessiner


def nouveau_document(titre, marges=18):
    tampon = BytesIO()
    page = SimpleDocTemplate(tampon, pagesize=A4, leftMargin=marges * mm, rightMargin=marges * mm,
                             topMargin=15 * mm, bottomMargin=20 * mm, title=titre)
    return tampon, page


def bloc_identites(params, client):
    emetteur = [Paragraph("<b>" + escape(params.get("nom") or "Entrepreneur individuel") + "</b>", NORMAL)]
    infos = []
    if params.get("adresse"):
        infos.append(params["adresse"])
    if params.get("siret"):
        infos.append("SIRET : " + params["siret"])
    if params.get("email"):
        infos.append(params["email"])
    if params.get("telephone"):
        infos.append(params["telephone"])
    emetteur.append(texte_multiligne(infos))
    destinataire = [Paragraph("<b>" + escape(client["nom"]) + "</b>", NORMAL)]
    infos_client = []
    if client.get("siren"):
        infos_client.append("SIREN : " + client["siren"])
    if client.get("adresse"):
        infos_client.append(client["adresse"])
    if client.get("email"):
        infos_client.append(client["email"])
    destinataire.append(texte_multiligne(infos_client))
    haut = Table([[Paragraph("Émetteur", PETIT), Paragraph("Client", PETIT)], [emetteur, destinataire]],
                 colWidths=[87 * mm, 87 * mm])
    haut.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"),
                              ("LINEBELOW", (0, 0), (-1, 0), 0.5, TRAIT),
                              ("LEFTPADDING", (0, 0), (-1, -1), 0),
                              ("BOTTOMPADDING", (0, 0), (-1, 0), 3)]))
    return haut


def pdf_document(doc, lignes, client, params, totaux, nature):
    type_doc = doc["type"]
    est_facture = type_doc == "facture"
    est_avoir = type_doc == "avoir"
    tampon, page = nouveau_document(doc["numero"])
    elements = []
    image = logo(params)
    if image is not None:
        elements.append(image)
        elements.append(Spacer(1, 3 * mm))
    elements.append(Paragraph({"facture": "FACTURE", "devis": "DEVIS", "avoir": "AVOIR"}[type_doc], TITRE))
    elements.append(Paragraph("N° " + escape(doc["numero"]), GRAS))
    if est_avoir and doc.get("origine_numero"):
        elements.append(Paragraph("Avoir relatif à la facture n° " + escape(doc["origine_numero"]), NORMAL))
    if doc.get("devis_numero"):
        elements.append(Paragraph("Suite au devis n° " + escape(doc["devis_numero"]), NORMAL))
    elements.append(Spacer(1, 5 * mm))
    elements.append(bloc_identites(params, client))
    elements.append(Spacer(1, 5 * mm))

    libelle_limite = "Date d'échéance" if est_facture else ("Valable jusqu'au" if type_doc == "devis" else "")
    entetes = [Paragraph("Date d'émission", PETIT)]
    valeurs = [Paragraph(date_fr(doc["date_emission"]), NORMAL)]
    if libelle_limite:
        entetes.append(Paragraph(libelle_limite, PETIT))
        valeurs.append(Paragraph(date_fr(doc["date_limite"]), NORMAL))
    if doc.get("date_prestation"):
        entetes.append(Paragraph("Date de la prestation", PETIT))
        valeurs.append(Paragraph(date_fr(doc["date_prestation"]), NORMAL))
    if doc.get("reference_client"):
        entetes.append(Paragraph("Votre référence", PETIT))
        valeurs.append(Paragraph(escape(doc["reference_client"]), NORMAL))
    entetes.append(Paragraph("Nature de l'opération", PETIT))
    valeurs.append(Paragraph(escape(nature), NORMAL))
    largeur = 174 * mm / len(entetes)
    dates = Table([entetes, valeurs], colWidths=[largeur] * len(entetes))
    dates.setStyle(TableStyle([("LEFTPADDING", (0, 0), (-1, -1), 0), ("VALIGN", (0, 0), (-1, -1), "TOP")]))
    elements.append(dates)
    if doc.get("objet"):
        elements.append(Spacer(1, 3 * mm))
        elements.append(Paragraph("<b>Objet :</b> " + escape(doc["objet"]), NORMAL))
    elements.append(Spacer(1, 5 * mm))

    avec_remise = False
    for l in lignes:
        if (l.get("remise") or 0) > 0:
            avec_remise = True
    entete = [Paragraph("Description", PETIT), Paragraph("Qté", PETIT), Paragraph("Prix unitaire", PETIT)]
    if avec_remise:
        entete.append(Paragraph("Remise", PETIT))
    entete.append(Paragraph("Total", PETIT))
    donnees = [entete]
    for l in lignes:
        total = outils.total_ligne(l)
        quantite = nb(l["quantite"]) + ((" " + l["unite"]) if l.get("unite") else "")
        ligne = [Paragraph(escape(l["description"]).replace("\n", "<br/>"), NORMAL),
                 Paragraph(escape(quantite), NORMAL), Paragraph(eur(l["prix_unitaire"]), NORMAL)]
        if avec_remise:
            ligne.append(Paragraph((nb(l["remise"]) + " %") if l.get("remise") else "", NORMAL))
        ligne.append(Paragraph(eur(total), NORMAL))
        donnees.append(ligne)
    if avec_remise:
        largeurs = [76 * mm, 22 * mm, 28 * mm, 18 * mm, 30 * mm]
    else:
        largeurs = [92 * mm, 22 * mm, 30 * mm, 30 * mm]
    tableau = Table(donnees, colWidths=largeurs, repeatRows=1)
    tableau.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), FOND), ("LINEBELOW", (0, 0), (-1, 0), 0.8, ACCENT),
        ("LINEBELOW", (0, 1), (-1, -1), 0.4, TRAIT), ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ("LEFTPADDING", (0, 0), (0, -1), 4)]))
    elements.append(tableau)
    elements.append(Spacer(1, 5 * mm))

    tva_active = params.get("tva_active") == "1"
    total_lignes = [[Paragraph("Total HT", NORMAL), Paragraph(eur(totaux["ht"]), DROITE)]]
    if tva_active:
        total_lignes.append([Paragraph("TVA " + nb(outils.num(params, "taux_tva")) + " %", NORMAL),
                             Paragraph(eur(totaux["tva"]), DROITE)])
        total_lignes.append([Paragraph("<b>Total TTC</b>", NORMAL),
                             Paragraph("<b>" + eur(totaux["ttc"]) + "</b>", DROITE)])
    else:
        libelle = "Montant à créditer" if est_avoir else "Net à payer"
        total_lignes.append([Paragraph("<b>" + libelle + "</b>", NORMAL),
                             Paragraph("<b>" + eur(totaux["ttc"]) + "</b>", DROITE)])
    index_dernier = len(total_lignes) - 1
    if est_facture:
        if totaux.get("total_avoirs"):
            total_lignes.append([Paragraph("Avoirs", NORMAL), Paragraph("- " + eur(totaux["total_avoirs"]), DROITE)])
        for p in totaux.get("paiements", []):
            etiquette = "Règlement du " + date_fr(p["date"])
            total_lignes.append([Paragraph(etiquette, NORMAL), Paragraph("- " + eur(p["montant"]), DROITE)])
        if totaux.get("paiements") or totaux.get("total_avoirs"):
            total_lignes.append([Paragraph("<b>Reste à payer</b>", NORMAL),
                                 Paragraph("<b>" + eur(max(totaux["reste"], 0)) + "</b>", DROITE)])
    bloc_total = Table(total_lignes, colWidths=[55 * mm, 36 * mm], hAlign="RIGHT")
    bloc_total.setStyle(TableStyle([("LINEABOVE", (0, index_dernier), (-1, index_dernier), 0.8, ACCENT),
                                    ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3)]))
    elements.append(bloc_total)
    elements.append(Spacer(1, 7 * mm))

    if doc.get("notes"):
        elements.append(texte_multiligne([doc["notes"]], NORMAL))
        elements.append(Spacer(1, 4 * mm))

    mentions = []
    if not tva_active:
        mentions.append("TVA non applicable, art. 293 B du CGI.")
    if est_facture:
        coordonnees = []
        if params.get("iban"):
            coordonnees.append("IBAN : " + params["iban"])
        if params.get("bic"):
            coordonnees.append("BIC : " + params["bic"])
        if coordonnees:
            mentions.append("Règlement par virement - " + "  ".join(coordonnees))
        mentions.append("Paiement à effectuer avant le " + date_fr(doc["date_limite"]) + ".")
        mentions.append("En cas de retard de paiement : pénalités égales à trois fois le taux d'intérêt "
                        "légal et indemnité forfaitaire pour frais de recouvrement de 40 €. "
                        "Pas d'escompte pour paiement anticipé.")
    elif type_doc == "devis":
        mentions.append("Devis gratuit, valable jusqu'au " + date_fr(doc["date_limite"]) + ".")
    if doc.get("conditions"):
        mentions.append(doc["conditions"])
    if params.get("mentions_pied"):
        mentions.append(params["mentions_pied"])
    for m in mentions:
        elements.append(Paragraph(escape(m).replace("\n", "<br/>"), PETIT))
        elements.append(Spacer(1, 1 * mm))

    if type_doc == "devis":
        elements.append(Spacer(1, 6 * mm))
        signature = Table([[Paragraph("Bon pour accord, date et signature du client :", NORMAL)]],
                          colWidths=[110 * mm], rowHeights=[28 * mm])
        signature.setStyle(TableStyle([("BOX", (0, 0), (-1, -1), 0.6, TRAIT), ("VALIGN", (0, 0), (-1, -1), "TOP")]))
        elements.append(signature)

    page.build(elements, onFirstPage=pied_de_page(params), onLaterPages=pied_de_page(params))
    return tampon.getvalue()


def tableau_liste(entetes, lignes, largeurs, ligne_total=None):
    donnees = [[Paragraph(e, PETIT) for e in entetes]]
    donnees.extend(lignes)
    if ligne_total is not None:
        donnees.append(ligne_total)
    tableau = Table(donnees, colWidths=largeurs, repeatRows=1)
    style = [("BACKGROUND", (0, 0), (-1, 0), FOND), ("LINEBELOW", (0, 0), (-1, 0), 0.8, ACCENT),
             ("VALIGN", (0, 0), (-1, -1), "TOP"), ("TOPPADDING", (0, 0), (-1, -1), 4),
             ("BOTTOMPADDING", (0, 0), (-1, -1), 4)]
    if ligne_total is not None:
        style.append(("LINEBELOW", (0, 1), (-1, -3), 0.4, TRAIT))
        style.append(("LINEABOVE", (0, -1), (-1, -1), 0.8, ACCENT))
    else:
        style.append(("LINEBELOW", (0, 1), (-1, -1), 0.4, TRAIT))
    tableau.setStyle(TableStyle(style))
    return tableau


def entete_registre(titre, params):
    elements = [Paragraph(titre, TITRE)]
    identite = [params.get("nom") or "", ("SIRET : " + params["siret"]) if params.get("siret") else ""]
    elements.append(texte_multiligne(identite, PETIT))
    elements.append(Spacer(1, 5 * mm))
    return elements


def pdf_recettes(recettes, annee, params):
    titre = "Livre des recettes " + str(annee)
    tampon, page = nouveau_document(titre, marges=14)
    elements = entete_registre(titre, params)
    lignes = []
    total = 0.0
    for r in recettes:
        total += r["montant"]
        lignes.append([Paragraph(date_fr(r["date_encaissement"]), NORMAL),
                       Paragraph(escape(r["reference"] or ""), NORMAL),
                       Paragraph(escape(r["client"] or ""), NORMAL),
                       Paragraph(escape(r["nature"] or ""), NORMAL),
                       Paragraph(escape(r["mode_paiement"] or ""), NORMAL),
                       Paragraph(eur(r["montant"]), DROITE)])
    ligne_total = [Paragraph("", NORMAL), Paragraph("", NORMAL), Paragraph("", NORMAL), Paragraph("", NORMAL),
                   Paragraph("<b>Total</b>", NORMAL), Paragraph("<b>" + eur(round(total, 2)) + "</b>", DROITE)]
    elements.append(tableau_liste(["Date", "Référence", "Client", "Nature", "Règlement", "Montant"], lignes,
                                  [22 * mm, 28 * mm, 40 * mm, 48 * mm, 22 * mm, 22 * mm], ligne_total))
    page.build(elements, onFirstPage=pied_de_page(params), onLaterPages=pied_de_page(params))
    return tampon.getvalue()


def pdf_depenses(depenses, annee, params):
    titre = "Registre des achats et dépenses " + str(annee)
    tampon, page = nouveau_document(titre, marges=14)
    elements = entete_registre(titre, params)
    lignes = []
    total = 0.0
    for d in depenses:
        total += d["montant"]
        lignes.append([Paragraph(date_fr(d["date"]), NORMAL), Paragraph(escape(d["fournisseur"] or ""), NORMAL),
                       Paragraph(escape(d["description"] or ""), NORMAL),
                       Paragraph(escape(d["categorie"] or ""), NORMAL),
                       Paragraph(eur(d["montant"]), DROITE)])
    ligne_total = [Paragraph("", NORMAL), Paragraph("", NORMAL), Paragraph("", NORMAL),
                   Paragraph("<b>Total</b>", NORMAL), Paragraph("<b>" + eur(round(total, 2)) + "</b>", DROITE)]
    elements.append(tableau_liste(["Date", "Fournisseur", "Description", "Catégorie", "Montant"], lignes,
                                  [22 * mm, 38 * mm, 62 * mm, 36 * mm, 24 * mm], ligne_total))
    page.build(elements, onFirstPage=pied_de_page(params), onLaterPages=pied_de_page(params))
    return tampon.getvalue()


def pdf_intervention(inter, client, taches, params):
    tampon, page = nouveau_document("Compte-rendu d'intervention")
    elements = []
    image = logo(params)
    if image is not None:
        elements.append(image)
        elements.append(Spacer(1, 3 * mm))
    elements.append(Paragraph("COMPTE-RENDU D'INTERVENTION", TITRE))
    elements.append(Spacer(1, 4 * mm))
    elements.append(bloc_identites(params, client))
    elements.append(Spacer(1, 5 * mm))
    minutes = inter["duree_minutes"] or 0
    duree = "{} h {:02d}".format(minutes // 60, minutes % 60)
    infos = Table([[Paragraph("Date", PETIT), Paragraph("Type", PETIT), Paragraph("Durée", PETIT)],
                   [Paragraph(date_fr(inter["date"]), NORMAL), Paragraph(escape(inter["type"] or ""), NORMAL),
                    Paragraph(duree, NORMAL)]], colWidths=[40 * mm, 90 * mm, 44 * mm])
    infos.setStyle(TableStyle([("LEFTPADDING", (0, 0), (-1, -1), 0)]))
    elements.append(infos)
    elements.append(Spacer(1, 4 * mm))
    elements.append(Paragraph(escape(inter["titre"]), SOUS_TITRE))
    if inter["description"]:
        elements.append(Spacer(1, 2 * mm))
        elements.append(texte_multiligne([inter["description"]], NORMAL))
    if taches:
        elements.append(Spacer(1, 5 * mm))
        elements.append(Paragraph("Étapes réalisées", SOUS_TITRE))
        lignes = []
        for t in taches:
            marque = "[x]" if t["fait"] else "[ ]"
            lignes.append([Paragraph(marque, NORMAL), Paragraph(escape(t["texte"]), NORMAL)])
        tableau = Table(lignes, colWidths=[12 * mm, 162 * mm])
        tableau.setStyle(TableStyle([("LINEBELOW", (0, 0), (-1, -1), 0.4, TRAIT),
                                     ("VALIGN", (0, 0), (-1, -1), "TOP")]))
        elements.append(tableau)
    page.build(elements, onFirstPage=pied_de_page(params), onLaterPages=pied_de_page(params))
    return tampon.getvalue()
