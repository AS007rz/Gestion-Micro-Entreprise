# -*- coding: utf-8 -*-
"""Routes : clients, fiche client, parc informatique."""
import csv
import io
from datetime import date

from flask import Response, abort, flash, redirect, render_template, request, url_for

import outils
from outils import TYPES_EQUIPEMENT, get_db, get_params, lire_nombre


def enregistrer(app):
    @app.route("/clients")
    def clients():
        db = get_db()
        params = get_params(db)
        q = request.args.get("q", "").strip()
        afficher_archives = request.args.get("archives") == "1"
        requete = ("SELECT c.*, (SELECT COUNT(*) FROM documents WHERE client_id = c.id) AS nb_docs, "
                   "(SELECT COUNT(*) FROM equipements WHERE client_id = c.id) AS nb_equipements "
                   "FROM clients c WHERE 1 = 1 ")
        args = []
        if not afficher_archives:
            requete += "AND c.actif = 1 "
        if q:
            requete += "AND (c.nom LIKE ? OR c.email LIKE ? OR c.siren LIKE ? OR c.telephone LIKE ?) "
            args.extend(["%" + q + "%"] * 4)
        requete += "ORDER BY c.nom"
        liste = []
        for c in db.execute(requete, args).fetchall():
            d = dict(c)
            ca = db.execute("SELECT COALESCE(SUM(r.montant), 0) FROM recettes r JOIN documents doc "
                            "ON doc.id = r.document_id WHERE doc.client_id = ?", (c["id"],)).fetchone()[0]
            impaye = 0.0
            for doc in db.execute("SELECT id FROM documents WHERE client_id = ? AND type = 'facture' "
                                  "AND statut IN ('emise', 'partielle')", (c["id"],)).fetchall():
                impaye += outils.totaux_document(db, doc["id"], params)["reste"]
            d["ca_total"] = round(ca, 2)
            d["impaye"] = round(impaye, 2)
            liste.append(d)
        return render_template("clients.html", clients=liste, q=q, archives=afficher_archives)

    @app.route("/clients/export.csv")
    def clients_csv():
        db = get_db()
        tampon = io.StringIO()
        ecrivain = csv.writer(tampon, delimiter=";")
        ecrivain.writerow(["Nom", "Type", "SIREN", "Adresse", "E-mail", "Téléphone", "Notes"])
        for c in db.execute("SELECT * FROM clients ORDER BY nom"):
            ecrivain.writerow([c["nom"], c["type"], c["siren"], c["adresse"].replace("\n", " "),
                               c["email"], c["telephone"], c["notes"].replace("\n", " ")])
        return Response("\ufeff" + tampon.getvalue(), mimetype="text/csv; charset=utf-8",
                        headers={"Content-Disposition": "attachment; filename=clients.csv"})

    @app.route("/clients/nouveau", methods=["GET", "POST"])
    @app.route("/clients/<int:client_id>/modifier", methods=["GET", "POST"])
    def client_formulaire(client_id=None):
        db = get_db()
        client = None
        if client_id is not None:
            client = db.execute("SELECT * FROM clients WHERE id = ?", (client_id,)).fetchone()
            if client is None:
                abort(404)
        if request.method == "POST":
            nom = request.form.get("nom", "").strip()
            if nom == "":
                flash("Le nom du client est obligatoire.", "danger")
                return render_template("client_form.html", client=request.form, nouveau=client is None)
            valeurs = (nom, request.form.get("siren", "").strip(), request.form.get("adresse", "").strip(),
                       request.form.get("email", "").strip(), request.form.get("telephone", "").strip(),
                       request.form.get("notes", "").strip(), request.form.get("type", "pro"),
                       lire_nombre(request.form.get("tarif_horaire", ""), 0.0),
                       int(lire_nombre(request.form.get("delai_paiement", ""), 0)),
                       1 if request.form.get("actif") else 0)
            if client is None:
                curseur = db.execute("INSERT INTO clients (nom, siren, adresse, email, telephone, notes, type, "
                                     "tarif_horaire, delai_paiement, actif) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                                     valeurs)
                db.commit()
                flash("Client ajouté.", "ok")
                return redirect(url_for("client_fiche", client_id=curseur.lastrowid))
            db.execute("UPDATE clients SET nom=?, siren=?, adresse=?, email=?, telephone=?, notes=?, type=?, "
                       "tarif_horaire=?, delai_paiement=?, actif=? WHERE id=?", valeurs + (client_id,))
            db.commit()
            flash("Client modifié.", "ok")
            return redirect(url_for("client_fiche", client_id=client_id))
        if client is None:
            client = {"nom": "", "siren": "", "adresse": "", "email": "", "telephone": "", "notes": "",
                      "type": "pro", "tarif_horaire": "", "delai_paiement": "", "actif": 1}
        return render_template("client_form.html", client=client, nouveau=client_id is None)

    @app.route("/clients/<int:client_id>")
    def client_fiche(client_id):
        db = get_db()
        params = get_params(db)
        client = db.execute("SELECT * FROM clients WHERE id = ?", (client_id,)).fetchone()
        if client is None:
            abort(404)
        docs = []
        impaye = 0.0
        for d in db.execute("SELECT * FROM documents WHERE client_id = ? ORDER BY date_emission DESC, "
                            "numero DESC", (client_id,)).fetchall():
            t = outils.totaux_document(db, d["id"], params)
            ligne = dict(d)
            ligne["ht"] = t["ht"]
            ligne["reste"] = t["reste"]
            docs.append(ligne)
            if d["type"] == "facture" and d["statut"] in ("emise", "partielle"):
                impaye += t["reste"]
        ca = db.execute("SELECT COALESCE(SUM(r.montant), 0) FROM recettes r JOIN documents d ON "
                        "d.id = r.document_id WHERE d.client_id = ?", (client_id,)).fetchone()[0]
        ca_annee = db.execute("SELECT COALESCE(SUM(r.montant), 0) FROM recettes r JOIN documents d ON "
                              "d.id = r.document_id WHERE d.client_id = ? AND substr(r.date_encaissement, 1, 4) = ?",
                              (client_id, str(date.today().year))).fetchone()[0]
        interventions = db.execute("SELECT * FROM interventions WHERE client_id = ? ORDER BY date DESC, id DESC "
                                   "LIMIT 15", (client_id,)).fetchall()
        minutes = db.execute("SELECT COALESCE(SUM(duree_minutes), 0) FROM interventions WHERE client_id = ?",
                             (client_id,)).fetchone()[0]
        contrats = db.execute("SELECT * FROM contrats WHERE client_id = ? ORDER BY actif DESC", (client_id,)).fetchall()
        equipements = db.execute("SELECT * FROM equipements WHERE client_id = ? ORDER BY type, nom",
                                 (client_id,)).fetchall()
        modifier = request.args.get("equipement", type=int)
        edition = None
        if modifier:
            edition = db.execute("SELECT * FROM equipements WHERE id = ? AND client_id = ?",
                                 (modifier, client_id)).fetchone()
        return render_template("client_fiche.html", client=client, docs=docs, impaye=round(impaye, 2),
                               ca=round(ca, 2), ca_annee=round(ca_annee, 2), interventions=interventions,
                               minutes=minutes, contrats=contrats, equipements=equipements,
                               edition=edition, types_equipement=TYPES_EQUIPEMENT,
                               aujourdhui=date.today().isoformat())

    @app.route("/clients/<int:client_id>/supprimer", methods=["POST"])
    def client_supprimer(client_id):
        db = get_db()
        liens = 0
        for table in ("documents", "interventions", "contrats"):
            liens += db.execute("SELECT COUNT(*) FROM {} WHERE client_id = ?".format(table),
                                (client_id,)).fetchone()[0]
        if liens > 0:
            db.execute("UPDATE clients SET actif = 0 WHERE id = ?", (client_id,))
            db.commit()
            flash("Ce client a un historique : il est archivé (conservé pour les factures) au lieu d'être supprimé.",
                  "info")
        else:
            db.execute("DELETE FROM equipements WHERE client_id = ?", (client_id,))
            db.execute("DELETE FROM clients WHERE id = ?", (client_id,))
            db.commit()
            flash("Client supprimé.", "ok")
        return redirect(url_for("clients"))

    # ------------------------------------------------------------ parc informatique
    @app.route("/clients/<int:client_id>/equipements", methods=["POST"])
    def equipement_enregistrer(client_id):
        db = get_db()
        nom = request.form.get("nom", "").strip()
        if nom == "":
            flash("Le nom de l'équipement est obligatoire.", "danger")
            return redirect(url_for("client_fiche", client_id=client_id))
        valeurs = (request.form.get("type", ""), nom, request.form.get("marque_modele", "").strip(),
                   request.form.get("os", "").strip(), request.form.get("ip", "").strip(),
                   request.form.get("numero_serie", "").strip(), request.form.get("date_achat", ""),
                   request.form.get("garantie_fin", ""), request.form.get("notes", "").strip())
        ident = request.form.get("id", type=int)
        if ident:
            db.execute("UPDATE equipements SET type=?, nom=?, marque_modele=?, os=?, ip=?, numero_serie=?, "
                       "date_achat=?, garantie_fin=?, notes=? WHERE id=? AND client_id=?",
                       valeurs + (ident, client_id))
            flash("Équipement modifié.", "ok")
        else:
            db.execute("INSERT INTO equipements (client_id, type, nom, marque_modele, os, ip, numero_serie, "
                       "date_achat, garantie_fin, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                       (client_id,) + valeurs)
            flash("Équipement ajouté.", "ok")
        db.commit()
        return redirect(url_for("client_fiche", client_id=client_id) + "#parc")

    @app.route("/equipements/<int:ident>/supprimer", methods=["POST"])
    def equipement_supprimer(ident):
        db = get_db()
        e = db.execute("SELECT client_id FROM equipements WHERE id = ?", (ident,)).fetchone()
        if e is None:
            abort(404)
        db.execute("UPDATE interventions SET equipement_id = NULL WHERE equipement_id = ?", (ident,))
        db.execute("DELETE FROM equipements WHERE id = ?", (ident,))
        db.commit()
        flash("Équipement supprimé.", "ok")
        return redirect(url_for("client_fiche", client_id=e["client_id"]) + "#parc")
