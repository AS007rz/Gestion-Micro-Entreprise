# -*- coding: utf-8 -*-
"""Outils communs : base de données, paramètres, calculs métier."""
import os
import secrets
import sqlite3
from datetime import date, timedelta

from flask import g, url_for

DOSSIER = os.path.dirname(os.path.abspath(__file__))
DOSSIER_DATA = os.path.join(DOSSIER, "data")
DOSSIER_SAUVEGARDES = os.path.join(DOSSIER_DATA, "sauvegardes")
DOSSIER_JUSTIFICATIFS = os.path.join(DOSSIER_DATA, "justificatifs")
DB_PATH = os.path.join(DOSSIER_DATA, "gestion.db")

# ---------------------------------------------------------------------------
# Valeurs légales 2026 (plafonds 2026-2028). A VERIFIER sur urssaf.fr / service-public.fr
# ---------------------------------------------------------------------------
PRESETS = {
    "services_bic": {
        "libelle": "Prestations de services (BIC)",
        "plafond_micro": 83600, "seuil_tva": 37500, "seuil_tva_majore": 41250,
        "taux_cotisations": 21.2, "taux_vl": 1.7, "abattement": 50,
    },
    "services_bnc": {
        "libelle": "Prestations de services libérales (BNC)",
        "plafond_micro": 83600, "seuil_tva": 37500, "seuil_tva_majore": 41250,
        "taux_cotisations": 25.6, "taux_vl": 2.2, "abattement": 34,
    },
    "vente": {
        "libelle": "Vente de marchandises",
        "plafond_micro": 203100, "seuil_tva": 85000, "seuil_tva_majore": 93500,
        "taux_cotisations": 12.3, "taux_vl": 1.0, "abattement": 71,
    },
}

PARAMS_DEFAUT = {
    "nom": "", "siret": "", "adresse": "", "email": "", "telephone": "",
    "iban": "", "bic": "", "site_web": "", "activite": "services_bic",
    "description_activite": "Maintenance, dépannage et supervision réseau",
    "date_creation": "", "tva_active": "0", "taux_tva": "20",
    "delai_paiement": "30", "acre": "0", "versement_liberatoire": "0",
    "periodicite_declaration": "mensuelle", "taux_horaire": "45",
    "taux_interet_legal": "", "mentions_pied": "", "mdp_hash": "", "logo": "",
    "assurance_rcpro": "",
}

STATUTS = {
    "emise": "Émise", "partielle": "Partiellement payée", "payee": "Payée",
    "soldee": "Soldée par avoir", "annulee": "Annulée", "envoye": "Envoyé",
    "accepte": "Accepté", "refuse": "Refusé", "emis": "Émis", "rembourse": "Remboursé",
    "planifiee": "Planifiée", "en_cours": "En cours", "terminee": "Terminée",
}
TYPES_DOC = {"facture": "Facture", "devis": "Devis", "avoir": "Avoir"}
PREFIXES = {"facture": "FAC", "devis": "DEV", "avoir": "AVO"}
MODES_PAIEMENT = ["Virement", "Carte bancaire", "Espèces", "Chèque", "PayPal", "Prélèvement", "Autre"]
UNITES = ["", "h", "forfait", "jour", "mois", "poste", "pièce", "km"]
TYPES_INTERVENTION = ["Dépannage à distance", "Dépannage sur site", "Migration de poste",
                      "Migration de données", "Mise à jour de poste", "Supervision réseau",
                      "Installation", "Conseil / audit", "Formation", "Autre"]
TYPES_EQUIPEMENT = ["Poste fixe", "Portable", "Serveur", "NAS", "Switch", "Routeur / box",
                    "Point d'accès Wi-Fi", "Imprimante", "Téléphonie IP", "Caméra", "Autre"]
CATEGORIES_DEPENSES = ["Matériel informatique", "Logiciels et abonnements", "Téléphone et internet",
                       "Déplacements", "Formation", "Assurance", "Comptabilité et banque",
                       "Fournitures", "Cotisations et taxes", "Autre"]
MOIS = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août",
        "septembre", "octobre", "novembre", "décembre"]

SCHEMA = """
CREATE TABLE IF NOT EXISTS parametres (cle TEXT PRIMARY KEY, valeur TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS clients (
    id INTEGER PRIMARY KEY AUTOINCREMENT, nom TEXT NOT NULL, siren TEXT DEFAULT '',
    adresse TEXT DEFAULT '', email TEXT DEFAULT '', telephone TEXT DEFAULT '', notes TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS documents (
    id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT NOT NULL, numero TEXT NOT NULL UNIQUE,
    client_id INTEGER NOT NULL REFERENCES clients(id), date_emission TEXT NOT NULL,
    date_limite TEXT NOT NULL, objet TEXT DEFAULT '', notes TEXT DEFAULT '', statut TEXT NOT NULL,
    date_paiement TEXT DEFAULT '', mode_paiement TEXT DEFAULT '', devis_origine_id INTEGER
);
CREATE TABLE IF NOT EXISTS lignes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    document_id INTEGER NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    description TEXT NOT NULL, quantite REAL NOT NULL, prix_unitaire REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS recettes (
    id INTEGER PRIMARY KEY AUTOINCREMENT, date_encaissement TEXT NOT NULL, reference TEXT DEFAULT '',
    client TEXT DEFAULT '', nature TEXT DEFAULT '', montant REAL NOT NULL, mode_paiement TEXT DEFAULT '',
    document_id INTEGER REFERENCES documents(id)
);
CREATE TABLE IF NOT EXISTS paiements (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    document_id INTEGER NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    date TEXT NOT NULL, montant REAL NOT NULL, mode TEXT DEFAULT '', reference TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS catalogue (
    id INTEGER PRIMARY KEY AUTOINCREMENT, nom TEXT NOT NULL, description TEXT DEFAULT '',
    unite TEXT DEFAULT '', prix REAL NOT NULL DEFAULT 0, actif INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS contrats (
    id INTEGER PRIMARY KEY AUTOINCREMENT, client_id INTEGER NOT NULL REFERENCES clients(id),
    nom TEXT NOT NULL, description TEXT DEFAULT '', montant REAL NOT NULL,
    periodicite TEXT NOT NULL DEFAULT 'mensuel', prochaine_echeance TEXT NOT NULL,
    date_debut TEXT DEFAULT '', date_fin TEXT DEFAULT '', actif INTEGER NOT NULL DEFAULT 1,
    notes TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS equipements (
    id INTEGER PRIMARY KEY AUTOINCREMENT, client_id INTEGER NOT NULL REFERENCES clients(id),
    type TEXT DEFAULT '', nom TEXT NOT NULL, marque_modele TEXT DEFAULT '', os TEXT DEFAULT '',
    ip TEXT DEFAULT '', numero_serie TEXT DEFAULT '', date_achat TEXT DEFAULT '',
    garantie_fin TEXT DEFAULT '', notes TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS interventions (
    id INTEGER PRIMARY KEY AUTOINCREMENT, client_id INTEGER NOT NULL REFERENCES clients(id),
    date TEXT NOT NULL, duree_minutes INTEGER NOT NULL DEFAULT 0, type TEXT DEFAULT '',
    titre TEXT NOT NULL, description TEXT DEFAULT '', statut TEXT NOT NULL DEFAULT 'terminee',
    facturable INTEGER NOT NULL DEFAULT 1, taux_horaire REAL DEFAULT 0, forfait REAL DEFAULT 0,
    frais_deplacement REAL DEFAULT 0, document_id INTEGER, equipement_id INTEGER
);
CREATE TABLE IF NOT EXISTS intervention_taches (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    intervention_id INTEGER NOT NULL REFERENCES interventions(id) ON DELETE CASCADE,
    texte TEXT NOT NULL, fait INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS modeles_checklist (
    id INTEGER PRIMARY KEY AUTOINCREMENT, nom TEXT NOT NULL, elements TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS depenses (
    id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT NOT NULL, fournisseur TEXT DEFAULT '',
    description TEXT DEFAULT '', categorie TEXT DEFAULT '', montant REAL NOT NULL,
    mode_paiement TEXT DEFAULT '', justificatif TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS declarations (
    id INTEGER PRIMARY KEY AUTOINCREMENT, periode TEXT NOT NULL UNIQUE, ca_declare REAL DEFAULT 0,
    declare_le TEXT DEFAULT '', paye_le TEXT DEFAULT '', montant_paye REAL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS taches (
    id INTEGER PRIMARY KEY AUTOINCREMENT, titre TEXT NOT NULL, echeance TEXT DEFAULT '',
    fait INTEGER NOT NULL DEFAULT 0, client_id INTEGER
);
"""

COLONNES_AJOUTEES = [
    ("clients", "type", "TEXT DEFAULT 'pro'"),
    ("clients", "tarif_horaire", "REAL DEFAULT 0"),
    ("clients", "delai_paiement", "INTEGER DEFAULT 0"),
    ("clients", "actif", "INTEGER DEFAULT 1"),
    ("documents", "facture_origine_id", "INTEGER"),
    ("documents", "reference_client", "TEXT DEFAULT ''"),
    ("documents", "date_prestation", "TEXT DEFAULT ''"),
    ("documents", "conditions", "TEXT DEFAULT ''"),
    ("documents", "contrat_id", "INTEGER"),
    ("documents", "derniere_relance", "TEXT DEFAULT ''"),
    ("documents", "nb_relances", "INTEGER DEFAULT 0"),
    ("lignes", "unite", "TEXT DEFAULT ''"),
    ("lignes", "remise", "REAL DEFAULT 0"),
    ("recettes", "paiement_id", "INTEGER"),
]

CHECKLISTS_DEFAUT = [
    ("Migration d'un poste Windows vers Linux", [
        "Inventaire des logiciels et des usages du client",
        "Sauvegarde complète des données du poste",
        "Vérification de la sauvegarde (test de restauration)",
        "Choix et préparation de la distribution Linux",
        "Installation (dual boot ou remplacement)",
        "Installation des logiciels équivalents",
        "Restauration des données et des profils (messagerie, navigateur)",
        "Configuration des imprimantes et périphériques",
        "Configuration réseau et accès aux partages",
        "Mises à jour et pare-feu",
        "Prise en main rapide avec l'utilisateur",
        "Recette avec le client",
        "Remise du compte-rendu"]),
    ("Mise à jour de poste", [
        "Sauvegarde ou point de restauration",
        "Mises à jour du système",
        "Mises à jour des logiciels et des pilotes",
        "Contrôle antivirus et pare-feu",
        "Nettoyage du disque et du démarrage",
        "Redémarrage et tests",
        "Compte-rendu au client"]),
    ("Transfert / migration de données", [
        "Inventaire des données à migrer",
        "Estimation du volume et de la durée",
        "Sauvegarde de la source",
        "Transfert vers la cible",
        "Contrôle d'intégrité (comparaison source / cible)",
        "Vérification des droits et des accès",
        "Validation avec le client",
        "Conservation de l'ancienne sauvegarde (durée convenue)"]),
    ("Dépannage réseau", [
        "Recueillir les symptômes",
        "Tester la connectivité (ping, DNS, passerelle)",
        "Contrôler box, routeur et switch",
        "Contrôler câblage et Wi-Fi",
        "Vérifier DHCP et adressage",
        "Corriger puis retester",
        "Documenter la solution"]),
    ("Supervision / contrôle mensuel", [
        "Vérifier l'état des sauvegardes",
        "Vérifier les mises à jour de sécurité",
        "Contrôler l'espace disque",
        "Contrôler les alertes et journaux",
        "Vérifier la connectivité et la bande passante",
        "Vérifier antivirus et pare-feu",
        "Rapport mensuel au client"]),
]

CATALOGUE_DEFAUT = [
    ("Intervention à distance", "", "h", 45),
    ("Intervention sur site", "", "h", 55),
    ("Frais de déplacement", "", "forfait", 15),
    ("Migration de poste vers Linux", "Sauvegarde, installation, restauration des données", "forfait", 150),
    ("Mise à jour de poste", "Système, logiciels et pilotes", "forfait", 40),
    ("Transfert de données", "Migration vers un autre poste ou serveur", "forfait", 60),
    ("Supervision réseau mensuelle", "Contrôles et rapport mensuel", "mois", 50),
]


# ---------------------------------------------------------------------------
# Base de données
# ---------------------------------------------------------------------------
def init_db():
    os.makedirs(DOSSIER_DATA, exist_ok=True)
    os.makedirs(DOSSIER_SAUVEGARDES, exist_ok=True)
    os.makedirs(DOSSIER_JUSTIFICATIFS, exist_ok=True)
    db = sqlite3.connect(DB_PATH)
    db.executescript(SCHEMA)
    for table, colonne, definition in COLONNES_AJOUTEES:
        existantes = [c[1] for c in db.execute("PRAGMA table_info({})".format(table))]
        if colonne not in existantes:
            db.execute("ALTER TABLE {} ADD COLUMN {} {}".format(table, colonne, definition))
    defauts = dict(PARAMS_DEFAUT)
    for cle, valeur in PRESETS["services_bic"].items():
        if cle != "libelle":
            defauts[cle] = str(valeur)
    for cle, valeur in defauts.items():
        db.execute("INSERT OR IGNORE INTO parametres (cle, valeur) VALUES (?, ?)", (cle, valeur))
    if db.execute("SELECT COUNT(*) FROM modeles_checklist").fetchone()[0] == 0:
        for nom, elements in CHECKLISTS_DEFAUT:
            db.execute("INSERT INTO modeles_checklist (nom, elements) VALUES (?, ?)",
                       (nom, "\n".join(elements)))
    if db.execute("SELECT COUNT(*) FROM catalogue").fetchone()[0] == 0:
        for nom, description, unite, prix in CATALOGUE_DEFAUT:
            db.execute("INSERT INTO catalogue (nom, description, unite, prix) VALUES (?, ?, ?, ?)",
                       (nom, description, unite, prix))
    # Reprise de la première version : paiements enregistrés sans table paiements
    anciens = db.execute(
        "SELECT d.id, d.date_paiement, d.mode_paiement FROM documents d "
        "WHERE d.type = 'facture' AND d.statut = 'payee' AND d.date_paiement != '' "
        "AND NOT EXISTS (SELECT 1 FROM paiements p WHERE p.document_id = d.id)").fetchall()
    for ancien in anciens:
        recette = db.execute("SELECT id, montant FROM recettes WHERE document_id = ?",
                             (ancien[0],)).fetchone()
        if recette is not None:
            curseur = db.execute("INSERT INTO paiements (document_id, date, montant, mode) "
                                 "VALUES (?, ?, ?, ?)", (ancien[0], ancien[1], recette[1], ancien[2]))
            db.execute("UPDATE recettes SET paiement_id = ? WHERE id = ?", (curseur.lastrowid, recette[0]))
    db.commit()
    db.close()


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


def fermer_db(erreur=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def get_params(db):
    params = {}
    for ligne in db.execute("SELECT cle, valeur FROM parametres"):
        params[ligne["cle"]] = ligne["valeur"]
    return params


def set_param(db, cle, valeur):
    db.execute("INSERT OR REPLACE INTO parametres (cle, valeur) VALUES (?, ?)", (cle, str(valeur)))


def cle_secrete():
    chemin = os.path.join(DOSSIER_DATA, "secret.key")
    os.makedirs(DOSSIER_DATA, exist_ok=True)
    if not os.path.exists(chemin):
        with open(chemin, "w") as fichier:
            fichier.write(secrets.token_hex(32))
    with open(chemin) as fichier:
        return fichier.read().strip()


def sauvegarde_auto():
    """Copie quotidienne de la base (30 dernières conservées)."""
    nom = "auto-{}.db".format(date.today().isoformat())
    chemin = os.path.join(DOSSIER_SAUVEGARDES, nom)
    if os.path.exists(chemin) or not os.path.exists(DB_PATH):
        return
    source = sqlite3.connect(DB_PATH)
    destination = sqlite3.connect(chemin)
    source.backup(destination)
    destination.close()
    source.close()
    anciennes = sorted([f for f in os.listdir(DOSSIER_SAUVEGARDES) if f.startswith("auto-")])
    while len(anciennes) > 30:
        os.remove(os.path.join(DOSSIER_SAUVEGARDES, anciennes.pop(0)))


# ---------------------------------------------------------------------------
# Petits outils
# ---------------------------------------------------------------------------
def lire_nombre(texte, defaut=0.0):
    try:
        return float(str(texte).replace(",", ".").replace(" ", "").replace("\u00a0", ""))
    except ValueError:
        return defaut


def num(params, cle):
    return lire_nombre(params.get(cle, "0"))


def formater_eur(valeur):
    texte = "{:,.2f}".format(valeur)
    return texte.replace(",", "\u00a0").replace(".", ",") + "\u00a0€"


def dernier_jour(annee, mois):
    if mois == 12:
        return date(annee, 12, 31)
    return date(annee, mois + 1, 1) - timedelta(days=1)


def ajouter_mois(jour, nombre):
    mois_total = jour.month - 1 + nombre
    annee = jour.year + mois_total // 12
    mois = mois_total % 12 + 1
    return date(annee, mois, min(jour.day, dernier_jour(annee, mois).day))


def jours_dans_annee(annee):
    return (date(annee, 12, 31) - date(annee, 1, 1)).days + 1


def date_creation(params):
    texte = params.get("date_creation", "")
    if texte:
        try:
            return date.fromisoformat(texte)
        except ValueError:
            return None
    return None


def plafond_proratise(params, annee):
    plafond = num(params, "plafond_micro")
    creation = date_creation(params)
    if creation is not None and creation.year == annee:
        jours = (date(annee, 12, 31) - creation).days + 1
        return round(plafond * jours / jours_dans_annee(annee), 2), True
    return plafond, False


def niveau(pourcentage):
    if pourcentage >= 100:
        return "depasse"
    if pourcentage >= 90:
        return "danger"
    if pourcentage >= 70:
        return "attention"
    return "ok"


def nature_operation(params):
    if params.get("activite") == "vente":
        return "Vente de marchandises"
    return "Prestation de services"


def taux_charges(params):
    """Part du CA prélevée (cotisations + versement libératoire éventuel), en fraction."""
    cotis = num(params, "taux_cotisations") / 100 * (1 - num(params, "acre") / 100)
    vl = num(params, "taux_vl") / 100 if params.get("versement_liberatoire") == "1" else 0
    return cotis, vl


# ---------------------------------------------------------------------------
# Documents : totaux, paiements, statuts, numéros
# ---------------------------------------------------------------------------
def total_ligne(ligne):
    remise = ligne["remise"] or 0
    return round(ligne["quantite"] * ligne["prix_unitaire"] * (1 - remise / 100), 2)


def montants_document(db, doc_id, params):
    lignes = db.execute("SELECT * FROM lignes WHERE document_id = ? ORDER BY id", (doc_id,)).fetchall()
    ht = 0.0
    for ligne in lignes:
        ht += total_ligne(ligne)
    ht = round(ht, 2)
    tva = 0.0
    if params.get("tva_active") == "1":
        tva = round(ht * num(params, "taux_tva") / 100, 2)
    return lignes, ht, tva, round(ht + tva, 2)


def totaux_document(db, doc_id, params):
    lignes, ht, tva, ttc = montants_document(db, doc_id, params)
    paiements = db.execute("SELECT * FROM paiements WHERE document_id = ? ORDER BY date, id",
                           (doc_id,)).fetchall()
    paye = round(sum([p["montant"] for p in paiements]), 2)
    avoirs = []
    total_avoirs = 0.0
    for a in db.execute("SELECT * FROM documents WHERE type = 'avoir' AND facture_origine_id = ? "
                        "ORDER BY id", (doc_id,)).fetchall():
        montant = montants_document(db, a["id"], params)[3]
        avoirs.append({"id": a["id"], "numero": a["numero"], "ttc": montant, "statut": a["statut"]})
        total_avoirs += montant
    total_avoirs = round(total_avoirs, 2)
    reste = round(ttc - paye - total_avoirs, 2)
    return {"lignes": lignes, "ht": ht, "tva": tva, "ttc": ttc, "paiements": paiements,
            "paye": paye, "avoirs": avoirs, "total_avoirs": total_avoirs, "reste": reste}


def part_ht(montant, ht, ttc):
    """Part HT d'un règlement TTC (identique au montant si pas de TVA)."""
    if ttc == 0:
        return montant
    return round(montant * ht / ttc, 2)


def recalculer_statut(db, params, doc_id):
    doc = db.execute("SELECT * FROM documents WHERE id = ?", (doc_id,)).fetchone()
    if doc is None or doc["type"] != "facture" or doc["statut"] == "annulee":
        return
    t = totaux_document(db, doc_id, params)
    du = round(t["ttc"] - t["total_avoirs"], 2)
    if du <= 0.005 and t["ttc"] > 0:
        statut = "soldee"
    elif t["paye"] >= du - 0.005:
        statut = "payee"
    elif t["paye"] > 0.005:
        statut = "partielle"
    else:
        statut = "emise"
    dernier = ""
    if t["paiements"]:
        dernier = t["paiements"][-1]["date"]
    db.execute("UPDATE documents SET statut = ?, date_paiement = ? WHERE id = ?", (statut, dernier, doc_id))


def enregistrer_paiement(db, params, doc_id, date_p, montant, mode, reference=""):
    doc = db.execute("SELECT * FROM documents WHERE id = ?", (doc_id,)).fetchone()
    client = db.execute("SELECT nom FROM clients WHERE id = ?", (doc["client_id"],)).fetchone()
    _, ht, _, ttc = montants_document(db, doc_id, params)
    curseur = db.execute("INSERT INTO paiements (document_id, date, montant, mode, reference) "
                         "VALUES (?, ?, ?, ?, ?)", (doc_id, date_p, montant, mode, reference))
    nature = nature_operation(params)
    if doc["objet"]:
        nature = nature + " - " + doc["objet"]
    db.execute("INSERT INTO recettes (date_encaissement, reference, client, nature, montant, "
               "mode_paiement, document_id, paiement_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
               (date_p, doc["numero"], client["nom"], nature, part_ht(montant, ht, ttc), mode,
                doc_id, curseur.lastrowid))
    recalculer_statut(db, params, doc_id)


def prochain_numero(db, type_doc, annee):
    debut = "{}-{}-".format(PREFIXES[type_doc], annee)
    ligne = db.execute("SELECT numero FROM documents WHERE type = ? AND numero LIKE ? "
                       "ORDER BY numero DESC LIMIT 1", (type_doc, debut + "%")).fetchone()
    suivant = 1
    if ligne is not None:
        suivant = int(ligne["numero"].split("-")[-1]) + 1
    return "{}{:03d}".format(debut, suivant)


def creer_document(db, params, type_doc, client_id, lignes, date_emission, date_limite, objet="",
                   notes="", **extra):
    """Crée un document et ses lignes. lignes = liste de (description, unite, quantite, prix, remise)."""
    numero = prochain_numero(db, type_doc, int(date_emission[:4]))
    statut = {"facture": "emise", "devis": "envoye", "avoir": "emis"}[type_doc]
    curseur = db.execute(
        "INSERT INTO documents (type, numero, client_id, date_emission, date_limite, objet, notes, "
        "statut, devis_origine_id, facture_origine_id, reference_client, date_prestation, "
        "conditions, contrat_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (type_doc, numero, client_id, date_emission, date_limite, objet, notes, statut,
         extra.get("devis_origine_id"), extra.get("facture_origine_id"),
         extra.get("reference_client", ""), extra.get("date_prestation", ""),
         extra.get("conditions", ""), extra.get("contrat_id")))
    doc_id = curseur.lastrowid
    for description, unite, quantite, prix, remise in lignes:
        db.execute("INSERT INTO lignes (document_id, description, unite, quantite, prix_unitaire, "
                   "remise) VALUES (?, ?, ?, ?, ?, ?)", (doc_id, description, unite, quantite, prix, remise))
    return doc_id, numero


def delai_client(params, client):
    delai = 0
    if client is not None and client["delai_paiement"]:
        delai = int(client["delai_paiement"])
    if delai <= 0:
        delai = int(num(params, "delai_paiement") or 30)
    return delai


def valeur_intervention(params, inter, client):
    minutes = inter["duree_minutes"] or 0
    taux = inter["taux_horaire"] or 0
    if taux <= 0 and client is not None:
        taux = client["tarif_horaire"] or 0
    if taux <= 0:
        taux = num(params, "taux_horaire")
    if inter["forfait"] and inter["forfait"] > 0:
        temps = inter["forfait"]
    else:
        temps = round(minutes / 60 * taux, 2)
    deplacement = inter["frais_deplacement"] or 0
    return {"taux": taux, "temps": round(temps, 2), "deplacement": deplacement,
            "total": round(temps + deplacement, 2), "heures": minutes / 60}


# ---------------------------------------------------------------------------
# Déclarations URSSAF
# ---------------------------------------------------------------------------
def periodes_declaration(params, annee):
    periodes = []
    creation = date_creation(params)
    if params.get("periodicite_declaration") == "trimestrielle":
        echeances = [date(annee, 4, 30), date(annee, 7, 31), date(annee, 10, 31), date(annee + 1, 1, 31)]
        for i in range(4):
            debut = date(annee, 3 * i + 1, 1)
            fin = dernier_jour(annee, 3 * i + 3)
            periodes.append({"cle": "{}-T{}".format(annee, i + 1),
                             "libelle": "T{} {}".format(i + 1, annee), "debut": debut, "fin": fin,
                             "echeance": echeances[i]})
    else:
        for mois in range(1, 13):
            fin = dernier_jour(annee, mois)
            suivant = ajouter_mois(date(annee, mois, 1), 1)
            periodes.append({"cle": "{}-{:02d}".format(annee, mois),
                             "libelle": "{} {}".format(MOIS[mois - 1].capitalize(), annee),
                             "debut": date(annee, mois, 1), "fin": fin,
                             "echeance": dernier_jour(suivant.year, suivant.month)})
    if creation is not None:
        periodes = [p for p in periodes if p["fin"] >= creation]
    return periodes


def etat_declarations(db, params, annee):
    cotis, vl = taux_charges(params)
    aujourdhui = date.today()
    resultat = []
    for p in periodes_declaration(params, annee):
        ca = db.execute("SELECT COALESCE(SUM(montant), 0) FROM recettes WHERE date_encaissement "
                        "BETWEEN ? AND ?", (p["debut"].isoformat(), p["fin"].isoformat())).fetchone()[0]
        ca = round(ca, 2)
        ligne = db.execute("SELECT * FROM declarations WHERE periode = ?", (p["cle"],)).fetchone()
        if ligne is not None and ligne["paye_le"]:
            statut = "payee"
        elif ligne is not None and ligne["declare_le"]:
            statut = "declaree"
        elif p["fin"] >= aujourdhui:
            statut = "en_cours"
        elif p["echeance"] < aujourdhui:
            statut = "en_retard"
        else:
            statut = "a_declarer"
        p = dict(p)
        p.update({"ca": ca, "cotisations": round(ca * cotis, 2), "vl": round(ca * vl, 2),
                  "ligne": ligne, "statut": statut})
        resultat.append(p)
    return resultat


STATUTS_DECLARATION = {"en_cours": "Période en cours", "a_declarer": "À déclarer",
                       "en_retard": "En retard", "declaree": "Déclarée", "payee": "Payée"}


# ---------------------------------------------------------------------------
# Tableau de bord
# ---------------------------------------------------------------------------
def calcul_stats(db, params, annee):
    aujourdhui = date.today()
    ca = round(db.execute("SELECT COALESCE(SUM(montant), 0) FROM recettes WHERE "
                          "substr(date_encaissement, 1, 4) = ?", (str(annee),)).fetchone()[0], 2)
    par_mois = [0.0] * 12
    for r in db.execute("SELECT substr(date_encaissement, 6, 2) AS mois, SUM(montant) AS total "
                        "FROM recettes WHERE substr(date_encaissement, 1, 4) = ? GROUP BY mois",
                        (str(annee),)):
        par_mois[int(r["mois"]) - 1] = r["total"]

    en_attente = 0.0
    nb_attente = 0
    if annee == aujourdhui.year:
        for d in db.execute("SELECT id FROM documents WHERE type = 'facture' AND "
                            "statut IN ('emise', 'partielle')").fetchall():
            t = totaux_document(db, d["id"], params)
            if t["reste"] > 0:
                en_attente += part_ht(t["reste"], t["ht"], t["ttc"])
                nb_attente += 1
    en_attente = round(en_attente, 2)

    plafond, proratise = plafond_proratise(params, annee)
    liste = [{"nom": "Plafond du régime micro", "valeur": plafond}]
    if params.get("tva_active") != "1":
        liste.append({"nom": "Franchise de TVA (seuil de base)", "valeur": num(params, "seuil_tva")})
        liste.append({"nom": "Franchise de TVA (seuil majoré)", "valeur": num(params, "seuil_tva_majore")})

    echelle = max(plafond, ca + en_attente, 1)
    jours_restants = None
    if annee == aujourdhui.year:
        jours_restants = (date(annee, 12, 31) - aujourdhui).days + 1

    alertes = []
    for s in liste:
        valeur = s["valeur"]
        s["pct"] = ca / valeur * 100 if valeur > 0 else 0
        s["reste"] = round(valeur - ca, 2)
        s["niveau"] = niveau(s["pct"])
        s["position"] = valeur / echelle * 100
        s["par_mois"] = None
        if jours_restants and s["reste"] > 0:
            s["par_mois"] = round(s["reste"] / (jours_restants / 30.4), 2)
        if s["niveau"] == "depasse":
            alertes.append(("danger", "{} dépassé : {} encaissés pour un seuil de {}.".format(
                s["nom"], formater_eur(ca), formater_eur(valeur))))
        elif s["niveau"] in ("danger", "attention"):
            alertes.append((s["niveau"], "{} : {:.0f} % atteint, il reste {}.".format(
                s["nom"], s["pct"], formater_eur(s["reste"]))))
        elif ca + en_attente >= valeur > 0:
            alertes.append(("attention", "Les factures en attente ({}) feraient dépasser « {} » "
                            "si elles étaient toutes payées cette année.".format(
                                formater_eur(en_attente), s["nom"])))

    projection = None
    if annee == aujourdhui.year:
        depart = date(annee, 1, 1)
        creation = date_creation(params)
        if creation is not None and creation.year == annee:
            depart = creation
        ecoules = (aujourdhui - depart).days + 1
        total = (date(annee, 12, 31) - depart).days + 1
        if ecoules >= 30 and ca > 0:
            projection = round(ca * total / ecoules, 2)

    cotis, vl_taux = taux_charges(params)
    cotisations = round(ca * cotis, 2)
    vl = round(ca * vl_taux, 2)
    depenses = round(db.execute("SELECT COALESCE(SUM(montant), 0) FROM depenses WHERE "
                                "substr(date, 1, 4) = ?", (str(annee),)).fetchone()[0], 2)
    return {
        "ca": ca, "par_mois": par_mois, "max_mois": max(par_mois + [1]),
        "en_attente": en_attente, "nb_attente": nb_attente, "seuils": liste,
        "echelle": echelle, "proratise": proratise, "plafond": plafond,
        "ca_pct": ca / echelle * 100, "attente_pct": en_attente / echelle * 100,
        "alertes": alertes, "projection": projection, "cotisations": cotisations, "vl": vl,
        "revenu_imposable": round(ca * (1 - num(params, "abattement") / 100), 2),
        "net": round(ca - cotisations - vl, 2), "depenses": depenses,
        "tresorerie": round(ca - cotisations - vl - depenses, 2),
    }


def construire_conseils(params, s, annee):
    conseils = []
    tva_active = params.get("tva_active") == "1"
    seuil_tva = num(params, "seuil_tva")
    seuil_majore = num(params, "seuil_tva_majore")
    plus_haut = max([x["pct"] for x in s["seuils"]] + [0])
    if not tva_active and seuil_tva > 0 and s["ca"] >= seuil_tva * 0.5:
        conseils.append(
            "TVA : la franchise s'arrête au-delà de {} (seuil de base). Entre {} et {}, la franchise "
            "est conservée jusqu'à la fin de l'année, puis la TVA s'applique. Au-delà de {}, elle "
            "s'applique immédiatement. Les clients professionnels (commerces, indépendants) "
            "récupèrent la TVA : pour eux, ajouter 20 % aux tarifs HT ne change rien. C'est surtout "
            "pour les particuliers que la marge est touchée.".format(
                formater_eur(seuil_tva), formater_eur(seuil_tva), formater_eur(seuil_majore),
                formater_eur(seuil_majore)))
    if plus_haut >= 70:
        conseils.append(
            "Le chiffre d'affaires est compté à la date d'encaissement, pas à la date de facture. "
            "Une facture payée en janvier compte pour l'année suivante. C'est un levier légitime pour "
            "lisser le CA autour d'un seuil, à condition de ne jamais antidater un paiement.")
    if plus_haut >= 90:
        conseils.append(
            "Dépasser le plafond du régime micro plusieurs années de suite fait basculer vers le "
            "régime réel. À ce stade, comparer micro, réel et société avec un expert-comptable "
            "(voir le simulateur micro / réel).")
    if params.get("versement_liberatoire") != "1":
        conseils.append(
            "Versement libératoire ({} % du CA) : il remplace l'impôt sur le revenu par un "
            "pourcentage du CA. Il peut être intéressant si le foyer fiscal est imposé dans une "
            "tranche élevée, mais il dépend d'une condition de revenu fiscal de référence et de "
            "délais d'option (à vérifier sur impots.gouv.fr et autoentrepreneur.urssaf.fr).".format(
                "{:g}".format(num(params, "taux_vl")).replace(".", ",")))
    creation = date_creation(params)
    if creation is not None and creation.year == annee and num(params, "acre") == 0:
        conseils.append(
            "ACRE : une réduction de cotisations est possible la première année selon la date "
            "d'immatriculation. Si elle s'applique, la renseigner dans les paramètres.")
    return conseils


def a_faire(db, params):
    """Liste des actions à mener : (niveau, texte, lien)."""
    items = []
    aujourdhui = date.today()
    auj = aujourdhui.isoformat()
    dans7 = (aujourdhui + timedelta(days=7)).isoformat()

    nb, total = 0, 0.0
    for d in db.execute("SELECT id FROM documents WHERE type = 'facture' AND statut IN "
                        "('emise', 'partielle') AND date_limite < ?", (auj,)).fetchall():
        t = totaux_document(db, d["id"], params)
        if t["reste"] > 0:
            nb += 1
            total += t["reste"]
    if nb:
        items.append(("danger", "{} facture{} en retard de paiement : {} à recouvrer.".format(
            nb, "s" if nb > 1 else "", formater_eur(total)), url_for("relances")))

    nb = db.execute("SELECT COUNT(*) FROM documents WHERE type = 'facture' AND statut IN "
                    "('emise', 'partielle') AND date_limite BETWEEN ? AND ?", (auj, dans7)).fetchone()[0]
    if nb:
        items.append(("info", "{} facture{} arrive{} à échéance dans les 7 jours.".format(
            nb, "s" if nb > 1 else "", "nt" if nb > 1 else ""), url_for("documents", statut="emise")))

    nb = db.execute("SELECT COUNT(*) FROM documents WHERE type = 'devis' AND statut = 'envoye'").fetchone()[0]
    if nb:
        items.append(("info", "{} devis en attente de réponse du client.".format(nb),
                      url_for("documents", type="devis", statut="envoye")))

    nb = db.execute("SELECT COUNT(*) FROM contrats WHERE actif = 1 AND prochaine_echeance <= ?",
                    (dans7,)).fetchone()[0]
    if nb:
        items.append(("attention", "{} contrat{} de maintenance à facturer.".format(
            nb, "s" if nb > 1 else ""), url_for("contrats")))

    nb, valeur = 0, 0.0
    for i in db.execute("SELECT i.*, c.tarif_horaire FROM interventions i JOIN clients c ON "
                        "c.id = i.client_id WHERE i.statut = 'terminee' AND i.facturable = 1 "
                        "AND i.document_id IS NULL").fetchall():
        nb += 1
        valeur += valeur_intervention(params, i, i)["total"]
    if nb:
        items.append(("attention", "{} intervention{} terminée{} non facturée{} (environ {}).".format(
            nb, "s" if nb > 1 else "", "s" if nb > 1 else "", "s" if nb > 1 else "",
            formater_eur(valeur)), url_for("interventions", filtre="a_facturer")))

    a_declarer = []
    for annee in (aujourdhui.year - 1, aujourdhui.year):
        for p in etat_declarations(db, params, annee):
            if p["statut"] in ("a_declarer", "en_retard"):
                a_declarer.append((annee, p))
    if len(a_declarer) == 1:
        annee, p = a_declarer[0]
        niv = "danger" if p["statut"] == "en_retard" else "attention"
        items.append((niv, "Déclaration URSSAF {} à faire avant le {}{}.".format(
            p["libelle"], p["echeance"].strftime("%d/%m/%Y"),
            " (CA " + formater_eur(p["ca"]) + ")" if p["ca"] else ""), url_for("declarations", annee=annee)))
    elif len(a_declarer) > 1:
        annee, premiere = a_declarer[0]
        en_retard = len([x for x in a_declarer if x[1]["statut"] == "en_retard"])
        niv = "danger" if en_retard else "attention"
        items.append((niv, "{} déclarations URSSAF à faire dont {} en retard (la plus ancienne : {}, échéance {}).".format(
            len(a_declarer), en_retard, premiere["libelle"], premiere["echeance"].strftime("%d/%m/%Y")),
            url_for("declarations", annee=annee)))

    for t in db.execute("SELECT * FROM taches WHERE fait = 0 AND echeance != '' AND echeance <= ? "
                        "ORDER BY echeance LIMIT 6", ((aujourdhui + timedelta(days=3)).isoformat(),)):
        niv = "danger" if t["echeance"] < auj else "info"
        items.append((niv, "Rappel : {} ({})".format(
            t["titre"], date.fromisoformat(t["echeance"]).strftime("%d/%m/%Y")), url_for("taches")))

    limite = (aujourdhui + timedelta(days=30)).isoformat()
    for e in db.execute("SELECT e.nom, e.garantie_fin, c.nom AS client FROM equipements e JOIN clients c "
                        "ON c.id = e.client_id WHERE e.garantie_fin != '' AND e.garantie_fin BETWEEN ? "
                        "AND ? ORDER BY e.garantie_fin LIMIT 5", (auj, limite)):
        items.append(("info", "Garantie de « {} » ({}) expire le {}.".format(
            e["nom"], e["client"], date.fromisoformat(e["garantie_fin"]).strftime("%d/%m/%Y")),
            url_for("clients")))

    if aujourdhui.month in (11, 12):
        items.append(("info", "CFE : l'avis arrive en fin d'année, paiement avant le 15 décembre "
                      "(exonération la première année d'activité).", None))
    return items


def annees_disponibles(db):
    annees = set([date.today().year])
    for r in db.execute("SELECT DISTINCT substr(date_encaissement, 1, 4) AS a FROM recettes"):
        annees.add(int(r["a"]))
    for r in db.execute("SELECT DISTINCT substr(date, 1, 4) AS a FROM depenses"):
        annees.add(int(r["a"]))
    return sorted(annees, reverse=True)
